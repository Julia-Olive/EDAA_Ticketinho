java -jar Ticketinho.jar
