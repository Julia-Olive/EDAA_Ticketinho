package com.suporte.service;

import com.suporte.estruturas.*;
import com.suporte.model.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Camada de serviço que coordena todas as operações do sistema Ticketinho.
 *
 * Esta classe é o único ponto de acesso as estruturas de dados internas.
 * Os painéis de interface não manipulam as estruturas diretamente; eles
 * delegam tudo para cá. Isso mantem a lógica de negócio separada da lógica
 * de apresentação.
 *
 * As quatro estruturas de dados coexistem por razoes diferentes:
 *   - ListaLigada: armazena todos os chamados para iteração completa
 *   - FilaChamados: mantém a ordem de atendimento (FIFO)
 *   - PilhaHistorico: registra chamados encerrados (LIFO)
 *   - ArvoreBinariaChamados: indexa por id para busca rápida (BST)
 *
 * Um chamado aberto existe simultaneamente na lista e na fila. Quando é
 * atendido, sai da fila. Quando é encerrado, entra na pilha. A lista e
 * a arvore nunca perdem o chamado.
 */
public class SupportService {

    // Repositório principal de todos os chamados cadastrados
    private final ListaLigada<Chamado> listaChamados = new ListaLigada<>();

    // Repositórios de entidades de suporte
    private final ListaLigada<Usuario>     listaUsuarios     = new ListaLigada<>();
    private final ListaLigada<Equipamento> listaEquipamentos = new ListaLigada<>();
    private final ListaLigada<Setor>       listaSetores      = new ListaLigada<>();

    // Estruturas especializadas para fluxo de atendimento e histórico
    private final FilaChamados          filaChamados    = new FilaChamados();
    private final PilhaHistorico        pilhaHistorico  = new PilhaHistorico();
    private final ArvoreBinariaChamados arvore          = new ArvoreBinariaChamados();

    // Sequências de id para cada entidade; iniciadas em 1
    private int proximoIdChamado    = 1;
    private int proximoIdUsuario    = 1;
    private int proximoIdEquipamento = 1;
    private int proximoIdSetor      = 1;

    /**
     * Inicializa o serviço e popula os dados de demonstração.
     * O construtor e o ponto de partida de toda a aplicação.
     */
    public SupportService() {
        popularDados();
    }

    /**
     * Carrega dados de exemplo para que o sistema inicie com conteudo visível.
     *
     * Está é uma conveniência para demonstração e não faz parte do fluxo
     * real de uso. Em uma versão com persistência, esses dados viriam do
     * banco de dados e este método não existiria.
     */
    private void popularDados() {
        // Setores da empresa
        Setor ti  = cadastrarSetor("Tecnologia da Informacao");
        Setor rh  = cadastrarSetor("Recursos Humanos");
        Setor fin = cadastrarSetor("Financeiro");
        cadastrarSetor("Comercial");
        cadastrarSetor("Area Comercial");

        // Equipamentos registrados no inventário
        Equipamento e1 = cadastrarEquipamento("Desktop Dell OptiPlex",       "Desktop",    "PAT-001", ti);
        Equipamento e2 = cadastrarEquipamento("Notebook Lenovo ThinkPad",    "Notebook",   "PAT-002", rh);
        Equipamento e3 = cadastrarEquipamento("Impressora HP LaserJet",      "Impressora", "PAT-003", fin);

        // Usuários: dois técnicos de TI e três solicitantes
        Usuario u1 = cadastrarUsuario("Lucas Marzocca",   "marzocca@ticketinho.com", "(11) 99999-0001", ti,  true);
        Usuario u2 = cadastrarUsuario("Andressa Rabelo",   "rabelo@empresa.com",    "(11) 99999-0002", rh,  false);
        Usuario u3 = cadastrarUsuario("Marcos Santos",   "santos@empresa.com",   "(11) 99999-0003", fin, false);
        Usuario u4 = cadastrarUsuario("Mylena Rocha",   "rocha@ticketinho.com",  "(11) 99999-0004", ti,  true);
        Usuario u5 = cadastrarUsuario("Matheus Guimaraes",   "guimaraes@empresa.com",    "(11) 99999-0005", rh,  false);
        Usuario u6 = cadastrarUsuario("Julia Oliveira",   "Oliveira@ticketinho.com",  "(11) 99999-0006", ti,  true);
       

        // Chamados iniciais que representam situações típicas do dia a dia
        abrirChamado("Servidor de arquivos inacessivel",
                "O servidor de arquivos da rede esta inacessivel para todos os usuarios do setor TI.",
                Prioridade.CRITICA, u2, e1, ti);

        abrirChamado("Computador nao inicializa",
                "Maquina nao liga apos atualizacao de ontem.",
                Prioridade.ALTA, u3, e1, rh);

        abrirChamado("Sistema ERP com lentidao",
                "O sistema ERP esta extremamente lento durante a emissao de notas.",
                Prioridade.MEDIA, u2, e2, fin);

        abrirChamado("Impressora exibe erro de papel",
                "Impressora retorna erro mesmo com papel na bandeja.",
                Prioridade.BAIXA, u3, e3, fin);

        // Simulação de um fluxo de trabalho: dois chamados são atendidos,
        // um deles resolvido e o outro cancelado pelo próprio usuário
        Chamado c1 = buscarChamadoPorId(1);
        atenderProximoChamado(u1);

        Chamado c2 = buscarChamadoPorId(2);
        atenderProximoChamado(u4);

        resolverChamado(c1, u1, "Reiniciado o servico de compartilhamento de arquivos no servidor.");
        cancelarChamado(c2, "Problema resolvido pelo proprio usuario.");
    }

    /**
     * Abre um novo chamado e o distribui para as três estruturas que precisam
     * conhecê-lo: a lista geral, a fila de atendimento e a árvore de busca.
     *
     * A inserção na árvore permite busca eficiente por id depois que o chamado
     * sair da fila.
     *
     * @param assunto     título do problema relatado
     * @param descricao   detalhamento do problema
     * @param prioridade  nível de urgência
     * @param solicitante usuário que abriu o chamado
     * @param equipamento ativo de TI relacionado (pode ser null)
     * @param setor       setor de origem
     * @return o chamado criado
     */
    public Chamado abrirChamado(String assunto, String descricao, Prioridade prioridade,
                                Usuario solicitante, Equipamento equipamento, Setor setor) {
        Chamado c = new Chamado(proximoIdChamado++, assunto, descricao,
                prioridade, solicitante, equipamento, setor);

        listaChamados.adicionar(c);
        filaChamados.enfileirar(c);
        arvore.inserir(c);

        return c;
    }

    /**
     * Retira o próximo chamado da fila de espera e o atribuí ao técnico informado.
     *
     * A mudança de status para EM_ATENDIMENTO e o registro da data são feitos
     * aqui, centralizando a lógica de transição de estado no serviço.
     *
     * @param técnico o técnico que ira assumir o atendimento
     * @return o chamado que saiu da fila, ou null se a fila estiver vazia
     */
    public Chamado atenderProximoChamado(Usuario tecnico) {
        Chamado c = filaChamados.desenfileirar();
        if (c == null) return null;

        c.setStatus(Status.EM_ATENDIMENTO);
        c.setTecnico(tecnico);
        c.setDataAtendimento(LocalDateTime.now());

        return c;
    }

    /**
     * Marca um chamado como resolvido e o move para o histórico.
     *
     * O chamado entra na pilha de histórico, de onde pode ser consultado
     * mesmo após o encerramento, sem precisar varrer a lista inteira.
     *
     * @param c        chamado a ser encerrado
     * @param tecnico  técnico responsável pela resolução 
     * @param resolucao descrição do que foi feito para resolver o problema
     */
    public void resolverChamado(Chamado c, Usuario tecnico, String resolucao) {
        c.setStatus(Status.RESOLVIDO);
        c.setResolucao(resolucao);
        c.setDataFechamento(LocalDateTime.now());
        pilhaHistorico.empilhar(c);
    }

    /**
     * Cancela um chamado e o registra no histórico com o motivo do cancelamento.
     *
     * O motivo e armazenado no campo resolução, que serve tanto para soluções
     * quanto para justificativas de cancelamento.
     *
     * @param c      chamado a ser cancelado
     * @param motivo texto explicando por que o chamado foi cancelado
     */
    public void cancelarChamado(Chamado c, String motivo) {
        c.setStatus(Status.CANCELADO);
        c.setResolucao(motivo);
        c.setDataFechamento(LocalDateTime.now());
        pilhaHistorico.empilhar(c);
    }

    /**
     * Busca um chamado pelo id usando a árvore binária de busca.
     * Mais eficiente do que varrer a lista inteira quando o número de
     * chamados é grande.
     *
     * @param id identificador do chamado
     * @return o chamado encontrado ou null
     */
    public Chamado buscarChamadoPorId(int id) {
        return arvore.buscarPorId(id);
    }

    /**
     * Busca chamados cujo assunto contêm o texto informado, sem diferenciar
     * maíusculas de minúsculas.
     *
     * A busca percorre toda a lista, portanto e O(n). Para volumes maiores,
     * seria preciso um índice de texto.
     *
     * @param título trecho do assunto a ser pesquisado
     * @return lista com todos os chamados que contêm o texto no assunto
     */
    public List<Chamado> buscarChamadosPorTitulo(String titulo) {
        List<Chamado> resultado = new ArrayList<>();
        for (Chamado c : listaChamados) {
            if (c.getAssunto().toLowerCase().contains(titulo.toLowerCase())) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    /**
     * Retorna todos os chamados cadastrados como uma lista comum do Java,
     * conveniente para uso com streams e lambdas nos paineis de UI.
     *
     * @return cópia da lista de chamados em ordem de cadastro
     */
    public List<Chamado> getListaTodosChamados() {
        List<Chamado> lista = new ArrayList<>();
        for (Chamado c : listaChamados) {
            lista.add(c);
        }
        return lista;
    }

    /**
     * Retorna todos os chamados ordenados por prioridade decrescente
     * (CRITICA primeiro, BAIXA por último).
     *
     * O comparador usa o ordinal() do enum negado para obter ordem decrescente,
     * o que funciona porque a enum Prioridade foi declarada em ordem crescente.
     *
     * @return lista de chamados ordenada por prioridade
     */
    public List<Chamado> listarChamadosOrdenadosPorPrioridade() {
        List<Chamado> lista = getListaTodosChamados();
        lista.sort(Comparator.comparingInt(c -> -c.getPrioridade().ordinal()));
        return lista;
    }

    // Acessores para as estruturas de dados, usados pelos paineis de UI

    public FilaChamados           getFilaChamados()      { return filaChamados; }
    public PilhaHistorico         getPilhaHistorico()    { return pilhaHistorico; }
    public ListaLigada<Usuario>   getListaUsuarios()     { return listaUsuarios; }
    public ListaLigada<Equipamento> getListaEquipamentos() { return listaEquipamentos; }
    public ListaLigada<Setor>     getListaSetores()      { return listaSetores; }

    /**
     * Cadastra um novo setor e o adiciona na lista de setores.
     *
     * @param nome nome do setor
     * @return o setor criado
     */
    public Setor cadastrarSetor(String nome) {
        Setor s = new Setor(proximoIdSetor++, nome);
        listaSetores.adicionar(s);
        return s;
    }

    /**
     * Cadastra um novo equipamento e o adiciona na lista de equipamentos.
     *
     * @param nome       nome descritivo do equipamento
     * @param tipo       categoria do equipamento
     * @param patrimonio número de patrimônio no inventário
     * @param setor      setor onde o equipamento está alocado
     * @return o equipamento criado
     */
    public Equipamento cadastrarEquipamento(String nome, String tipo, String patrimonio, Setor setor) {
        Equipamento e = new Equipamento(proximoIdEquipamento++, nome, tipo, patrimonio, setor);
        listaEquipamentos.adicionar(e);
        return e;
    }

    /**
     * Cadastra um novo usuário e o adiciona na lista de usuários.
     *
     * @param nome     nome completo do usuário
     * @param email    e-mail de contato
     * @param telefone telefone de contato
     * @param setor    setor ao qual o usuário pertence
     * @param tecnico  true se o usuário e técnico de TI
     * @return o usuario criado
     */
    public Usuario cadastrarUsuario(String nome, String email, String telefone,
                                    Setor setor, boolean tecnico) {
        Usuario u = new Usuario(proximoIdUsuario++, nome, email, telefone, setor, tecnico);
        listaUsuarios.adicionar(u);
        return u;
    }

    /**
     * Retorna apenas os usuários com perfil de técnico.
     * Usado para popular o combo de atribuiçãoo de chamados.
     *
     * @return lista de tecnicos cadastrados
     */
    public List<Usuario> getTecnicos() {
        List<Usuario> lista = new ArrayList<>();
        for (Usuario u : listaUsuarios) {
            if (u.isTecnico()) lista.add(u);
        }
        return lista;
    }
}
