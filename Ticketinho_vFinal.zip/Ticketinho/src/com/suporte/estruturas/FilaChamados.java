package com.suporte.estruturas;

import com.suporte.model.Chamado;

/**
 * Fila FIFO para gerenciamento de chamados aguardando atendimento.
 *
 * A ordem de chegada e respeitada: o primeiro chamado aberto é o primeiro
 * a ser atendido, o que garante justiça no atendimento independentemente
 * da prioridade. O dashboard exibe a fila em tempo real para que os técnicos
 * saibam quantos chamados estao aguardando.
 *
 * A implementação usa nós encadeados internamente, sem depender das coleções
 * do Java Collections Framework. O ponteiro {@code head} aponta para o proximo
 * a ser atendido e {@code tail} para o último que entrou na fila.
 */
public class FilaChamados {

    private No head;
    private No tail;
    private int tamanho;

    /**
     * Nó interno da fila. Cada nó guarda o chamado e a referência para o
     * próximo na fila.
     */
    private static class No {
        Chamado dado;
        No prox;

        No(Chamado dado) { this.dado = dado; }
    }

    /**
     * Adiciona um chamado no final da fila (operação de enqueue).
     *
     * Se a fila estava vazia, o novo nó passa a ser ao mesmo tempo
     * o head e o tail.
     *
     * @param c chamado a ser adicionado na fila de espera
     */
    public void enfileirar(Chamado c) {
        No novo = new No(c);

        if (tail != null) {
            tail.prox = novo;
        }
        tail = novo;

        // Primeiro elemento: head e tail apontam para o mesmo nó
        if (head == null) {
            head = novo;
        }

        tamanho++;
    }

    /**
     * Remove e retorna o chamado do início da fila (operação de dequeue).
     *
     * Quando o último elemento e removido, ambos os ponteiros voltam a null,
     * sinalizando fila vazia.
     *
     * @return o chamado mais antigo na fila, ou null se estiver vazia
     */
    public Chamado desenfileirar() {
        if (head == null) return null;

        Chamado dado = head.dado;
        head = head.prox;

        // Se ficou sem elementos, tail também deve ser nulo
        if (head == null) {
            tail = null;
        }

        tamanho--;
        return dado;
    }

    /**
     * Retorna o próximo chamado sem remove-lo da fila.
     * Útil para exibir quem será atendido em seguida sem alterar o estado.
     *
     * @return o chamado na cabeça da fila, ou null se vazia
     */
    public Chamado peek() {
        return head != null ? head.dado : null;
    }

    public int getTamanho() { return tamanho; }

    public boolean isEmpty() { return tamanho == 0; }
}
