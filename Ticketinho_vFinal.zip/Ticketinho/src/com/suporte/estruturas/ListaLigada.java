package com.suporte.estruturas;

import java.util.Iterator;

/**
 * Lista simplesmente encadeada é que serve como repositório principal
 * de entidades do sistema: chamados, usuários, equipamentos e setores.
 *
 * A implementação não usa nenhuma estrutura do Java Collections Framework.
 * Os elementos são inseridos sempre no final, mantendo a ordem de cadastro.
 * A remoção percorre a lista linearmente, portanto e O(n).
 *
 * A interface {@code Iterable} foi implementada para permitir o uso em loops
 * for-each, tornando o código de leitura mais expressivo nos paineis de UI
 * e na camada de serviço.
 *
 * @param <T> tipo dos elementos armazenados na lista
 */
public class ListaLigada<T> implements Iterable<T> {

    private No<T> head;
    private int tamanho;

    /**
     * No interno genérico que guarda o dado e a referência para o próximo.
     */
    private static class No<T> {
        T dado;
        No<T> prox;

        No(T dado) { this.dado = dado; }
    }

    /**
     * Adiciona um elemento no final da lista.
     * O percurso até o último nó é necessário porque não mantemos um ponteiro
     * para o tail nessa implementação (foi priorizada a simplicidade).
     *
     * @param dado elemento a ser inserido
     */
    public void adicionar(T dado) {
        No<T> novo = new No<>(dado);

        if (head == null) {
            head = novo;
        } else {
            // Percorre até o último nó para encadear o novo
            No<T> atual = head;
            while (atual.prox != null) {
                atual = atual.prox;
            }
            atual.prox = novo;
        }

        tamanho++;
    }

    /**
     * Remove a primeira ocorrência do elemento informado, usando o método
     * {@code equals} para comparação.
     *
     * Se o elemento não existir, nenhuma alteração é feita.
     *
     * @param dado elemento a ser removido
     */
    public void remover(T dado) {
        if (head == null) return;

        // Caso especial: o elemento a remover é o primeiro da lista
        if (head.dado.equals(dado)) {
            head = head.prox;
            tamanho--;
            return;
        }

        // Percorre buscando o nó anterior ao que será removido
        No<T> atual = head;
        while (atual.prox != null) {
            if (atual.prox.dado.equals(dado)) {
                atual.prox = atual.prox.prox;
                tamanho--;
                return;
            }
            atual = atual.prox;
        }
    }

    /**
     * Retorna o elemento na posição informada (indice base zero).
     * Não há verificação de bounds aqui; o chamador é responsável por
     * garantir um índice válido.
     *
     * @param index posição desejada
     * @return elemento na posição
     */
    public T get(int index) {
        No<T> atual = head;
        for (int i = 0; i < index; i++) {
            atual = atual.prox;
        }
        return atual.dado;
    }

    public int getTamanho() { return tamanho; }

    public boolean isEmpty() { return tamanho == 0; }

    /**
     * Fornece um iterator anônimo para suporte ao for-each.
     * O estado atual do percurso é mantido na váriavel {@code atual},
     * que avança a cada chamada de {@code next()}.
     */
    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            No<T> atual = head;

            @Override
            public boolean hasNext() {
                return atual != null;
            }

            @Override
            public T next() {
                T dado = atual.dado;
                atual = atual.prox;
                return dado;
            }
        };
    }
}
