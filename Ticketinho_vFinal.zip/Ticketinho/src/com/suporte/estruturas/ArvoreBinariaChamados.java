package com.suporte.estruturas;

import com.suporte.model.Chamado;

/**
 * Árvore Binária de Busca armazena chamados indexados pelo id.
 *
 * A estrutura permite busca em O(log n) no caso médio, o que é mais eficiente
 * do que varrer a lista ligada inteira quando o volume de chamados for grande.
 *
 * A árvore não é balanceada (sem rotacoes AVL ou Red-Black), portanto em um
 * cenário de ids estritamente crescentes ela degenera para O(n).
 *
 * Os chamados são inseridos pelo id (chave inteira) e nunca removidos da árvore,
 *já que o histórico precisa ser consultável mesmo após o encerramento.
 */
public class ArvoreBinariaChamados {

    private No raiz;

    /**
     * Nó interno da árvore. Encapsulado como classe privada porque nenhum
     * código externo precisa conhecer a estrutura interna de linkagem.
     */
    private static class No {
        Chamado dado;
        No esq, dir;

        No(Chamado dado) { this.dado = dado; }
    }

    /**
     * Insere um chamado naárvore usando o id como chave de ordenacao.
     * Ids duplicados são ignorados silenciosamente (nao substitui o existente).
     */
    public void inserir(Chamado c) {
        raiz = inserir(raiz, c);
    }

    /**
     * Inserção recursiva: desce pela árvore comparando ids até encontrar
     * uma posicão vazia, onde cria um novo nó.
     */
    private No inserir(No no, Chamado c) {
        if (no == null) return new No(c);

        if (c.getId() < no.dado.getId()) {
            no.esq = inserir(no.esq, c);
        } else if (c.getId() > no.dado.getId()) {
            no.dir = inserir(no.dir, c);
        }
        // Id igual: o chamado já existe, não faz nada

        return no;
    }

    /**
     * Busca um chamado pelo id. Retorna null se o id não existir na árvore.
     *
     * @param id identificador do chamado
     * @return o chamado encontrado ou null
     */
    public Chamado buscarPorId(int id) {
        return buscar(raiz, id);
    }

    /**
     * Busca recursiva: desce para a esquerda se o id buscado é menor,
     * para a direita se é maior, ou retorna o no atual se for igual.
     */
    private Chamado buscar(No no, int id) {
        if (no == null) return null;

        if (id == no.dado.getId()) return no.dado;
        if (id < no.dado.getId())  return buscar(no.esq, id);

        return buscar(no.dir, id);
    }
}
