package com.suporte.estruturas;

import com.suporte.model.Chamado;
import java.util.ArrayList;
import java.util.List;

/**
 * Pilha LIFO que registra o histórico de chamados
 * encerrados, sejam resolvidos ou cancelados.
 *
 * O topo da pilha sempre representa o chamado encerrado mais recentemente,
 * o que facilita a exibição cronológica invertida na tela de histórico.
 * O usuário vê primeiro o que acabou de acontecer.
 *
 * A implementação usa nós encadeados sem depender de ArrayList ou Stack
 * do Java. O método {@code toList()} converte a pilha para lista quando
 * e necessário popular tabelas na interface.
 */
public class PilhaHistorico {

    private No topo;
    private int tamanho;

    /**
     * No interno da pilha. Cada nó aponta para o nó que estava abaixo
     * dele antes de ser empilhado.
     */
    private static class No {
        Chamado dado;
        No abaixo;

        No(Chamado dado) { this.dado = dado; }
    }

    /**
     * Empilha um chamado encerrado no topo do histórico.
     *
     * O novo nó passa a apontar para o antigo topo, e depois é promovido
     * a novo topo da pilha.
     *
     * @param c chamado que foi resolvido ou cancelado
     */
    public void empilhar(Chamado c) {
        No novo = new No(c);
        novo.abaixo = topo;
        topo = novo;
        tamanho++;
    }

    /**
     * Remove e retorna o chamado do topo da pilha.
     *
     * @return o chamado encerrado mais recente, ou null se a pilha estiver vazia
     */
    public Chamado desempilhar() {
        if (topo == null) return null;

        Chamado dado = topo.dado;
        topo = topo.abaixo;
        tamanho--;
        return dado;
    }

    /**
     * Retorna o chamado do topo sem removê-lo.
     * Útil para consultar o último chamado encerrado sem alterar o estado da pilha.
     *
     * @return o chamado no topo ou null se vazia
     */
    public Chamado peek() {
        return topo != null ? topo.dado : null;
    }

    public int getTamanho() { return tamanho; }

    public boolean isEmpty() { return tamanho == 0; }

    /**
     * Converte o conteúdo da pilha em uma lista, do topo para a base.
     *
     * Usado pelo painel de histórico para popular a tabela de exibição.
     * A ordem resultante é do mais recente para o mais antigo, que é
     * justamente o que o usuário espera ver primeiro.
     *
     * @return lista de chamados em ordem de mais recente a mais antigo
     */
    public List<Chamado> toList() {
        List<Chamado> lista = new ArrayList<>();
        No atual = topo;
        while (atual != null) {
            lista.add(atual.dado);
            atual = atual.abaixo;
        }
        return lista;
    }
}
