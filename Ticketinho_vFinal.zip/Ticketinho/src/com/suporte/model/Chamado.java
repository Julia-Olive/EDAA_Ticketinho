package com.suporte.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa um chamado de suporte técnico, que é a unidade central de trabalho
 * do sistema Ticketinho.
 *
 * Cada chamado nasce com status ABERTO e percorre um ciclo de vida definido
 * pelos métodos do serviõ: abertura, atendimento, resolução ou cancelamento.
 *
 * O identificador numérico (id) é gerado pelo serviço e usado como chave
 * na árvore binária de busca, portanto deve ser único e imutável ápos a criação.
 */
public class Chamado {

    // Formato padrão para exibição de datas na interface
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private int id;
    private String assunto;
    private String descricao;
    private String resolucao;
    private Prioridade prioridade;
    private Status status;
    private Usuario solicitante;
    private Usuario tecnico;
    private Equipamento equipamento;
    private Setor setor;
    private LocalDateTime dataAbertura;
    private LocalDateTime dataAtendimento;
    private LocalDateTime dataFechamento;

    /**
     * Cria um novo chamado com os dados essenciais informados pelo solicitante.
     *
     * O status inicial e sempre ABERTO e a data de abertura é registrada
     * automaticamente no momento da instanciação.
     *
     * @param id          identificador único gerado pelo serviço
     * @param assunto     título resumido do problema
     * @param descricao   detalhamento do problema relatado
     * @param prioridade  nivel de urgência definido pelo solicitante
     * @param solicitante usuário que abriu o chamado
     * @param equipamento ativo de TI relacionado ao problema (pode ser null)
     * @param setor       setor de origem do chamado
     */
    public Chamado(int id, String assunto, String descricao, Prioridade prioridade,
                   Usuario solicitante, Equipamento equipamento, Setor setor) {
        this.id = id;
        this.assunto = assunto;
        this.descricao = descricao;
        this.prioridade = prioridade;
        this.solicitante = solicitante;
        this.equipamento = equipamento;
        this.setor = setor;
        this.status = Status.ABERTO;
        this.dataAbertura = LocalDateTime.now();
    }

    // Getters e setters dos campos imutáveis

    public int getId() { return id; }
    public String getAssunto() { return assunto; }
    public String getDescricao() { return descricao; }

    // Campos que mudam ao longo do ciclo de vida do chamado

    public String getResolucao() { return resolucao; }
    public void setResolucao(String r) { this.resolucao = r; }

    public Prioridade getPrioridade() { return prioridade; }
    public void setPrioridade(Prioridade p) { this.prioridade = p; }

    public Status getStatus() { return status; }
    public void setStatus(Status s) { this.status = s; }

    public Usuario getSolicitante() { return solicitante; }

    public Usuario getTecnico() { return tecnico; }
    public void setTecnico(Usuario t) { this.tecnico = t; }

    public Equipamento getEquipamento() { return equipamento; }
    public void setEquipamento(Equipamento e) { this.equipamento = e; }

    public Setor getSetor() { return setor; }

    public LocalDateTime getDataAbertura() { return dataAbertura; }

    public LocalDateTime getDataAtendimento() { return dataAtendimento; }
    public void setDataAtendimento(LocalDateTime d) { this.dataAtendimento = d; }

    public LocalDateTime getDataFechamento() { return dataFechamento; }
    public void setDataFechamento(LocalDateTime d) { this.dataFechamento = d; }

    /**
     * Retorna a data de abertura formatada para exibição na interface.
     * Devolve "-" quando a data não está disponível, evitando NPE na UI.
     */
    public String getDataAberturaFormatada() {
        return dataAbertura != null ? dataAbertura.format(FORMATTER) : "-";
    }

    /**
     * Retorna a data de início de atendimento formatada.
     * Será "-" enquanto o chamado ainda não tiver sido retirado da fila.
     */
    public String getDataAtendimentoFormatada() {
        return dataAtendimento != null ? dataAtendimento.format(FORMATTER) : "-";
    }

    /**
     * Retorna a data de encerramento formatada.
     * Será "-" enquanto o chamado ainda estiver em aberto ou em atendimento.
     */
    public String getDataFechamentoFormatada() {
        return dataFechamento != null ? dataFechamento.format(FORMATTER) : "-";
    }

    /**
     * Representação textual usada em logs e em campos de texto simples.
     * O prefixo "CHM-" com zero-padding facilita a ordenação lexicográfica.
     */
    @Override
    public String toString() {
        return String.format("CHM-%04d | %s | %s | %s", id, assunto, prioridade, status);
    }
}
