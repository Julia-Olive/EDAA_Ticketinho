package com.suporte.model;

/**
 * Define os níveis de prioridade de um chamado, do menos ao mais urgente.
 *
 * A ordem de declaração dos valores importa: o método {@code ordinal()} é
 * usado pela camada de serviço para ordenar chamados por prioridade decrescente
 * na listagem do dashboard. Portanto, nunca altere a ordem sem revisar
 * {@code SupportService.listarChamadosOrdenadosPorPrioridade()}.
 *
 * Cada valor carrega a cor hexadecimal que representa a prioridade na interface,
 * evitando que a logica de coloração fique espalhada pelos paineis de UI.
 */
public enum Prioridade {

    BAIXA("#28a745"),
    MEDIA("#ffc107"),
    ALTA("#fd7e14"),
    CRITICA("#dc3545");

    // Cor em formato hexadecimal usada pela interface para destacar a prioridade
    private final String cor;

    Prioridade(String cor) { this.cor = cor; }

    public String getCor() { return cor; }

    /**
     * Retorna o rótulo em português para exibição na interface.
     * O switch nível de prioridade 
     */
    @Override
    public String toString() {
        return switch (this) {
            case BAIXA   -> "Baixa";
            case MEDIA   -> "Media";
            case ALTA    -> "Alta";
            case CRITICA -> "Critica";
        };
    }

    /**
     * Converte uma string de exibição de volta para o enum.
     * Retorna BAIXA como valor padrão quando a string não corresponde
     * a nenhum valor conhecido, evitando exceção em dados inconsistentes.
     *
     * @param s string de exibição da prioridade
     * @return prioridade correspondente ou BAIXA se desconhecida
     */
    public static Prioridade fromString(String s) {
        return switch (s) {
            case "Baixa"  -> BAIXA;
            case "Media"  -> MEDIA;
            case "Alta"   -> ALTA;
            case "Critica" -> CRITICA;
            default        -> BAIXA;
        };
    }
}
