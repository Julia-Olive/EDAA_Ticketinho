package com.suporte.model;

/**
 * Ativo de TI cadastrado no sistema que pode ser associado a um chamado.
 *
 * O número de patrimônio e o identificador físico do bem no inventário
 * da empresa, permitindo rastrear quais equipamentos apresentam mais
 * problemas ao longo do tempo.
 */
public class Equipamento {

    private int id;
    private String nome;
    private String tipo;

    // Número de patrimônio do ativo conforme registro no inventário
    private String patrimonio;
    private Setor setor;

    /**
     * Cria um equipamento com todos os dados de identificação necessários.
     *
     * @param id         identificador único gerado pelo serviço
     * @param nome       descrição do equipamento, como "Desktop Dell OptiPlex"
     * @param tipo       categoria do ativo, como "Desktop", "Notebook" ou "Impressora"
     * @param patrimonio código de patrimônio do bem no inventário físico
     * @param setor      setor onde o equipamento está alocado
     */
    public Equipamento(int id, String nome, String tipo, String patrimonio, Setor setor) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.patrimonio = patrimonio;
        this.setor = setor;
    }

    public int getId() { return id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTipo() { return tipo; }

    public String getPatrimonio() { return patrimonio; }

    public Setor getSetor() { return setor; }
    public void setSetor(Setor setor) { this.setor = setor; }

    /**
     * Exibe apenas o nome do equipamento nos combos e tabelas da interface.
     */
    @Override
    public String toString() { return nome; }
}
