package com.suporte.model;

/**
 * Representa um usuário do sistema, que pode ser um solicitante comum
 * ou um técnico de TI responsável por atender chamados.
 *
 * O campo {@code tecnico} determina o perfil de uso: técnicos aparecem
 * nas opções de atribuição de chamados, enquanto os demais so aparecem
 * na lista de solicitantes.
 */
public class Usuario {

    private int id;
    private String nome;
    private String email;
    private String telefone;
    private Setor setor;

    // Indica se o usuário pode ser atríbuido como técnico responsável por um chamado
    private boolean tecnico;

    /**
     * Cria um usuário com todos os dados necessários para identificação
     * e contato dentro do sistema.
     *
     * @param id       identificador único gerado pelo serviço
     * @param nome     nome completo do usuário
     * @param email    endereçoo de e-mail para contato
     * @param telefone número de telefone para contato
     * @param setor    setor ao qual o usuário pertence
     * @param tecnico  true se o usuário é técnico de TI
     */
    public Usuario(int id, String nome, String email, String telefone, Setor setor, boolean tecnico) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.setor = setor;
        this.tecnico = tecnico;
    }

    public int getId() { return id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }

    public Setor getSetor() { return setor; }
    public void setSetor(Setor setor) { this.setor = setor; }

    public boolean isTecnico() { return tecnico; }

    /**
     * O nome é usado diretamente em JComboBoxes e campos de texto da interface,
     * por isso o toString retorna apenas o nome sem informações adicionais.
     */
    @Override
    public String toString() { return nome; }
}
