package com.suporte.model;

/**
 * Setor organizacional da empresa ao qual usuários e equipamentos podem
 * ser vinculados.
 *
 * O setor é usado para filtrar chamados e organizar relatórios por área,
 * facilitando a identificação de quais departamentos geram mais demandas.
 */
public class Setor {

    private int id;
    private String nome;

    /**
     * Cria um setor com identificador único e nome descritivo.
     *
     * @param id   identificador único gerado pelo serviço
     * @param nome nome do setor, como "Tecnologia da Informação"
     */
    public Setor(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() { return id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    /**
     * Retorna o nome do setor diretamente, pois é isso que precisa aparecer
     * nos combos e tabelas da interface.
     */
    @Override
    public String toString() { return nome; }
}
