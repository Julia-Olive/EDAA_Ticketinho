package com.suporte.model;

/**
 * Representa o ciclo de vida de um chamado dentro do sistema Ticketinho.
 *
 * A progressão normal é: ABERTO -> EM_ATENDIMENTO -> RESOLVIDO -> FECHADO.
 * O caminho alternativo é o cancelamento, que pode ocorrer a partir de
 * qualquer estado anterior ao fechamento.
 *
 * Cada valor carrega o rótulo de exibição e a cor para uso direto na
 * interface, centralizando essas decisões no modelo em vez de espalhá-las
 * pelos paineis de UI.
 */
public enum Status {

    ABERTO("Aberto", "#0d6efd"),
    EM_ATENDIMENTO("Em Atendimento", "#ffc107"),
    RESOLVIDO("Resolvido", "#28a745"),
    FECHADO("Fechado", "#6c757d"),
    CANCELADO("Cancelado", "#dc3545");

    // Texto de exibição para o usuário final
    private final String label;

    // Cor hexadecimal para destaque visual na tabela e nos detalhes do chamado
    private final String cor;

    Status(String label, String cor) {
        this.label = label;
        this.cor = cor;
    }

    public String getLabel() { return label; }
    public String getCor()   { return cor; }

    /**
     * Retorna o rótulo legível para exibição em tabelas e campos de texto.
     */
    @Override
    public String toString() { return label; }
}
