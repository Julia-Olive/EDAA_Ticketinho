package com.suporte.ui;

import com.suporte.model.*;
import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * Painel de gerenciamento de chamados do Ticketinho.
 *
 * Lista todos os chamados cadastrados com suporte a filtro por texto.
 * As ações disponíveis na barra inferior refletem o ciclo de vida de um chamado:
 * abertura, atendimento, resolução e cancelamento.
 *
 * A abertura de novo chamado e o atendimento são operações globais que
 * afetam o Dashboard e o Histórico. Por isso, após cada uma delas,
 * {@code janela.atualizarTudo()} é chamado para sincronizar os outros paineis.
 */
public class PainelChamados extends JPanel {

    private final SupportService service;
    private final JanelaPrincipal janela;
    private DefaultTableModel mdl;
    private JTable tabela;
    private JTextField txtBusca;

    /**
     * Cria o painel e monta a estrutura visual inicial.
     *
     * @param service serviço de suporte compartilhado
     * @param janela  referência para a janela principal
     */
    public PainelChamados(SupportService service, JanelaPrincipal janela) {
        this.service = service;
        this.janela  = janela;
        setBackground(Tema.getBgApp());
        setLayout(new BorderLayout());
        construir();
    }

    /**
     * Monta o header com campo de busca e botão de novo chamado,
     * a tabela principal e a barra de ações na parte inferior.
     */
    private void construir() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(Tema.getBgApp());
        header.setBorder(new EmptyBorder(28, 28, 16, 28));

        JPanel tituloBox = new JPanel();
        tituloBox.setLayout(new BoxLayout(tituloBox, BoxLayout.Y_AXIS));
        tituloBox.setOpaque(false);

        JLabel titulo = new JLabel("Chamados");
        titulo.setFont(Tema.FONTE_TITULO);
        titulo.setForeground(Tema.getTextoPrimario());

        JLabel sub = new JLabel("Gerencie e acompanhe os chamados");
        sub.setFont(Tema.FONTE_BODY);
        sub.setForeground(Tema.getTextoSecundario());

        tituloBox.add(titulo);
        tituloBox.add(Box.createVerticalStrut(3));
        tituloBox.add(sub);
        header.add(tituloBox, BorderLayout.WEST);

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        acoes.setOpaque(false);

        txtBusca = Tema.campo();
        txtBusca.setPreferredSize(new Dimension(220, 36));

        JButton btnBuscar = Tema.botaoSecundario("Buscar");
        btnBuscar.addActionListener(e -> filtrar());
        txtBusca.addActionListener(e -> filtrar());

        JButton btnNovo = Tema.botaoPrimario("+ Novo Chamado");
        btnNovo.addActionListener(e -> abrirFormularioNovoChamado());

        acoes.add(txtBusca);
        acoes.add(btnBuscar);
        acoes.add(Box.createHorizontalStrut(4));
        acoes.add(btnNovo);
        header.add(acoes, BorderLayout.EAST);

        // Tabela principal de chamados
        mdl = new DefaultTableModel(
                new String[]{"#", "Assunto", "Prioridade", "Status", "Solicitante", "Tecnico", "Setor", "Abertura"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = criarTabela();

        // Barra de ações com as operações do ciclo de vida
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bottomBar.setBackground(Tema.getBgCard());
        bottomBar.setBorder(new EmptyBorder(10, 16, 10, 16));

        JButton btnAtender  = Tema.botaoPrimario("Iniciar Atendimento");
        JButton btnResolver = Tema.botaoSecundario("Resolver");
        JButton btnCancelar = Tema.botaoPerigo("Cancelar");
        JButton btnDetalhe  = Tema.botaoSecundario("Detalhes");

        btnAtender.addActionListener(e  -> atenderSelecionado());
        btnResolver.addActionListener(e -> resolverSelecionado());
        btnCancelar.addActionListener(e -> cancelarSelecionado());
        btnDetalhe.addActionListener(e  -> verDetalhesSelecionado());

        bottomBar.add(btnAtender);
        bottomBar.add(btnResolver);
        bottomBar.add(btnCancelar);
        bottomBar.add(Box.createHorizontalStrut(8));
        bottomBar.add(btnDetalhe);

        JPanel corpo = new JPanel(new BorderLayout());
        corpo.setBackground(Tema.getBgCard());
        corpo.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0, 28, 28, 28, Tema.getBgApp()),
                new LineBorder(Tema.getBorda(), 1, true)));
        corpo.add(Tema.scrollPane(tabela), BorderLayout.CENTER);
        corpo.add(bottomBar, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(corpo, BorderLayout.CENTER);
    }

    /**
     * Cria a tabela de chamados com renderizadores coloridos para as colunas
     * Prioridade e Status, e larguras pré-definidas para as colunas principais.
     *
     * @return tabela estilizada pronta para uso
     */
    private JTable criarTabela() {
        JTable t = new JTable(mdl) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                boolean sel = isRowSelected(row);
                c.setBackground(sel ? Tema.getSelecaoSolida()
                               : row % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                c.setForeground(Tema.getTextoPrimario());
                return c;
            }
        };
        t.setFont(Tema.FONTE_BODY);
        t.setRowHeight(38);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setSelectionBackground(Tema.getSelecaoSolida());

        JTableHeader h = t.getTableHeader();
        h.setBackground(Tema.getBgSidebar());
        h.setForeground(Tema.getTextoMuted());
        h.setFont(new Font("Segoe UI", Font.BOLD, 11));
        h.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        h.setReorderingAllowed(false);

        DefaultTableCellRenderer pad = new DefaultTableCellRenderer();
        pad.setBorder(new EmptyBorder(0, 12, 0, 12));

        // Renderizador da coluna Prioridade: texto colorido conforme o nivel de urgência
        DefaultTableCellRenderer prio = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                setForeground(Tema.corPrioridade(v != null ? v.toString() : ""));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        // Renderizador da coluna Status: texto colorido conforme o estado do chamado
        DefaultTableCellRenderer status = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                setForeground(Tema.corStatus(v != null ? v.toString() : ""));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        for (int i = 0; i < mdl.getColumnCount(); i++) {
            String col = mdl.getColumnName(i);
            TableColumn tc = t.getColumnModel().getColumn(i);
            if      (col.equals("Prioridade")) tc.setCellRenderer(prio);
            else if (col.equals("Status"))     tc.setCellRenderer(status);
            else                               tc.setCellRenderer(pad);
        }

        t.getColumnModel().getColumn(0).setPreferredWidth(60);
        t.getColumnModel().getColumn(1).setPreferredWidth(220);
        t.getColumnModel().getColumn(2).setPreferredWidth(90);
        t.getColumnModel().getColumn(3).setPreferredWidth(120);
        return t;
    }

    /**
     * Filtra os chamados exibidos na tabela com base no texto do campo de busca.
     * Se o campo estiver vazio, exibe todos os chamados.
     */
    private void filtrar() {
        String b = txtBusca.getText().trim();
        preencherTabela(b.isEmpty()
                ? service.getListaTodosChamados()
                : service.buscarChamadosPorTitulo(b));
    }

    /**
     * Popula a tabela com a lista de chamados fornecida.
     * Limpa as linhas anteriores antes de inserir os novos dados.
     *
     * @param lista chamados a serem exibidos
     */
    private void preencherTabela(List<Chamado> lista) {
        mdl.setRowCount(0);
        for (Chamado c : lista) {
            mdl.addRow(new Object[]{
                String.format("#%04d", c.getId()),
                c.getAssunto(),
                c.getPrioridade().toString(),
                c.getStatus().toString(),
                c.getSolicitante() != null ? c.getSolicitante().getNome() : "-",
                c.getTecnico()    != null ? c.getTecnico().getNome()    : "-",
                c.getSetor()      != null ? c.getSetor().getNome()      : "-",
                c.getDataAberturaFormatada()
            });
        }
    }

    /**
     * Retorna o chamado correspondente a linha selecionada na tabela.
     * Extrai o id da primeira coluna e faz a busca na árvore via serviço.
     *
     * @return o chamado selecionado ou null se nenhuma linha estiver selecionada
     */
    private Chamado getChamadoSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) return null;
        String id = mdl.getValueAt(row, 0).toString().replace("#", "").trim();
        return service.buscarChamadoPorId(Integer.parseInt(id));
    }

    // ----- Helpers de dialog -----

    /**
     * Cria um dialog modal padrão com o tamanho e título informados.
     * Todos os diálogs de ação do painel usam este método como base.
     *
     * @param titulo título do dialog
     * @param w      largura em pixels
     * @param h      altura em pixels
     * @return dialog configurado mas ainda não visível
     */
    private JDialog novoDialog(String titulo, int w, int h) {
        JDialog d = new JDialog(janela, titulo, true);
        d.setSize(w, h);
        d.setLocationRelativeTo(janela);
        d.getContentPane().setBackground(Tema.getBgDialog());
        d.setResizable(false);
        return d;
    }

    /**
     * Cria o painel de formulário padrão usado dentro dos dialogs.
     * O GridBagLayout permite alinhar labels e campos de forma flexível.
     *
     * @return painel de formulário estilizado
     */
    private JPanel dialogPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Tema.getBgDialog());
        p.setBorder(new EmptyBorder(24, 28, 24, 28));
        return p;
    }

    /**
     * Cria um label de campo de formulário com fonte e cor padrão para labels.
     *
     * @param t texto do label
     * @return label estilizado
     */
    private JLabel dialogLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(Tema.FONTE_BOLD);
        l.setForeground(Tema.getTextoSecundario());
        return l;
    }

    /**
     * Cria um painel de botões alinhado a direita, sem fundo visível.
     * Padrão usado no rodapé dos dialogs de ação.
     *
     * @param btns botões a serem adicionados
     * @return painel com os botões alinhados a direita
     */
    private JPanel btnRowPanel(JButton... btns) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        p.setBackground(Tema.getBgDialog());
        for (JButton b : btns) p.add(b);
        return p;
    }

    /**
     * Configura o GridBagConstraints padrão usado nos formulários dos dialogs.
     * Todos os campos ocupam a largura total e tem insets zerados por padrão.
     *
     * @return constraints configurados
     */
    private GridBagConstraints gbc() {
        GridBagConstraints g = new GridBagConstraints();
        g.fill    = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;
        g.gridx   = 0;
        g.insets  = new Insets(0, 0, 0, 0);
        return g;
    }

    // ----- Acoes do ciclo de vida dos chamados -----

    /**
     * Exibe o dialog de atendimento, permitindo escolher o técnico responsável.
     *
     * Verifica se há chamados na fila e se há técnicos cadastrados antes
     * de abrir o dialog, evitando que o usuário abra um formulário que
     * não pode ser submetido.
     */
    private void atenderSelecionado() {
        if (service.getFilaChamados().isEmpty()) {
            alerta("Nao ha chamados na fila de espera.");
            return;
        }
        List<Usuario> tecs = service.getTecnicos();
        if (tecs.isEmpty()) {
            alerta("Nenhum tecnico cadastrado.");
            return;
        }

        JDialog d = novoDialog("Iniciar Atendimento", 420, 210);
        JPanel form = dialogPanel();
        GridBagConstraints g = gbc();

        g.gridy = 0;
        form.add(dialogLabel("Tecnico responsavel:"), g);

        g.gridy = 1;
        JComboBox<Usuario> cb = Tema.combo();
        tecs.forEach(cb::addItem);
        cb.setPreferredSize(new Dimension(0, 36));
        form.add(cb, g);

        g.gridy = 2;
        g.insets = new Insets(20, 0, 0, 0);
        JButton ok     = Tema.botaoPrimario("Iniciar");
        JButton cancel = Tema.botaoSecundario("Cancelar");
        cancel.addActionListener(e -> d.dispose());
        ok.addActionListener(e -> {
            service.atenderProximoChamado((Usuario) cb.getSelectedItem());
            janela.atualizarTudo();
            atualizar();
            d.dispose();
        });
        form.add(btnRowPanel(cancel, ok), g);

        d.setContentPane(form);
        d.setVisible(true);
    }

    /**
     * Exibe o dialog de resolução para o chamado selecionado na tabela.
     * Requer que uma linha esteja selecionada.
     */
    private void resolverSelecionado() {
        Chamado c = getChamadoSelecionado();
        if (c == null) {
            alerta("Selecione um chamado.");
            return;
        }

        JDialog d = novoDialog("Resolver Chamado", 480, 300);
        JPanel form = dialogPanel();
        GridBagConstraints g = gbc();

        g.gridy = 0;
        form.add(dialogLabel("Descricao da resolucao:"), g);

        g.gridy = 1;
        JTextArea ta = Tema.areaTexto(5);
        ta.setPreferredSize(new Dimension(0, 100));
        JScrollPane sp = Tema.scrollPane(ta);
        sp.setPreferredSize(new Dimension(0, 110));
        sp.setBorder(new LineBorder(Tema.getBorda(), 1, true));
        form.add(sp, g);

        g.gridy = 2;
        g.insets = new Insets(16, 0, 0, 0);
        JButton ok     = Tema.botaoPrimario("Resolver");
        JButton cancel = Tema.botaoSecundario("Cancelar");
        cancel.addActionListener(e -> d.dispose());
        ok.addActionListener(e -> {
            service.resolverChamado(c, c.getTecnico(), ta.getText());
            janela.atualizarTudo();
            atualizar();
            d.dispose();
        });
        form.add(btnRowPanel(cancel, ok), g);

        d.setContentPane(form);
        d.setVisible(true);
    }

    /**
     * Exibe o dialog de confirmação de cancelamento para o chamado selecionado.
     * O botão de confirmação usa o estilo de perigo (vermelho) para reforcar
     * que a ação é irreversível.
     */
    private void cancelarSelecionado() {
        Chamado c = getChamadoSelecionado();
        if (c == null) {
            alerta("Selecione um chamado.");
            return;
        }

        JDialog d = novoDialog("Cancelar Chamado", 420, 200);
        JPanel form = dialogPanel();
        GridBagConstraints g = gbc();

        g.gridy = 0;
        JLabel msg = new JLabel(String.format(
                "<html>Confirmar cancelamento do Chamado <b>#%04d</b>?</html>", c.getId()));
        msg.setFont(Tema.FONTE_BODY);
        msg.setForeground(Tema.getTextoPrimario());
        form.add(msg, g);

        g.gridy = 1;
        g.insets = new Insets(20, 0, 0, 0);
        JButton sim = Tema.botaoPerigo("Cancelar Chamado");
        JButton nao = Tema.botaoSecundario("Voltar");
        nao.addActionListener(e -> d.dispose());
        sim.addActionListener(e -> {
            service.cancelarChamado(c, "Cancelado pelo operador.");
            janela.atualizarTudo();
            atualizar();
            d.dispose();
        });
        form.add(btnRowPanel(nao, sim), g);

        d.setContentPane(form);
        d.setVisible(true);
    }

    /**
     * Exibe os detalhes completos do chamado selecionado na tabela.
     */
    private void verDetalhesSelecionado() {
        Chamado c = getChamadoSelecionado();
        if (c == null) {
            alerta("Selecione um chamado.");
            return;
        }
        exibirDetalhes(c);
    }

    /**
     * Abre um dialog de leitura com todos os campos do chamado.
     *
     * O layout usa GridBagConstraints para alinhar labels e valores em
     * duas colunas. A descrição é exibida em uma JTextArea não editável
     * para preservar a formatação original.
     *
     * @param c chamado a ser detalhado
     */
    private void exibirDetalhes(Chamado c) {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Tema.getBgDialog());
        form.setBorder(new EmptyBorder(20, 24, 20, 24));

        GridBagConstraints g = new GridBagConstraints();
        g.anchor = GridBagConstraints.WEST;
        g.insets  = new Insets(4, 4, 4, 16);
        g.fill    = GridBagConstraints.HORIZONTAL;

        // Pares label/valor dos campos principais do chamado
        String[][] campos = {
            {"Assunto:",      c.getAssunto()},
            {"Status:",       c.getStatus().toString()},
            {"Prioridade:",   c.getPrioridade().toString()},
            {"Setor:",        c.getSetor()       != null ? c.getSetor().getNome()       : "-"},
            {"Solicitante:",  c.getSolicitante() != null ? c.getSolicitante().getNome() : "-"},
            {"Tecnico:",      c.getTecnico()     != null ? c.getTecnico().getNome()     : "-"},
            {"Equipamento:",  c.getEquipamento() != null ? c.getEquipamento().getNome() : "-"},
            {"Abertura:",     c.getDataAberturaFormatada()},
            {"Atendimento:",  c.getDataAtendimentoFormatada()},
            {"Fechamento:",   c.getDataFechamentoFormatada()},
        };

        for (int i = 0; i < campos.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0;
            JLabel lbl = new JLabel(campos[i][0]);
            lbl.setFont(Tema.FONTE_BOLD);
            lbl.setForeground(Tema.getTextoSecundario());
            form.add(lbl, g);

            g.gridx = 1; g.weightx = 1;
            JLabel val = new JLabel(campos[i][1]);
            val.setFont(Tema.FONTE_BODY);
            val.setForeground(Tema.getTextoPrimario());
            form.add(val, g);
        }

        // Descrição em área de texto para manter formatação e permitir scroll
        if (c.getDescricao() != null && !c.getDescricao().isEmpty()) {
            g.gridx = 0; g.gridy = campos.length; g.weightx = 0;
            JLabel ld = new JLabel("Descricao:");
            ld.setFont(Tema.FONTE_BOLD);
            ld.setForeground(Tema.getTextoSecundario());
            form.add(ld, g);

            g.gridx = 1; g.weightx = 1;
            JTextArea ta = Tema.areaTexto(3);
            ta.setText(c.getDescricao());
            ta.setEditable(false);
            JScrollPane sp = Tema.scrollPane(ta);
            sp.setPreferredSize(new Dimension(300, 70));
            sp.setBorder(new LineBorder(Tema.getBorda(), 1, true));
            form.add(sp, g);
        }

        JDialog d = novoDialog(String.format("Chamado #%04d", c.getId()), 560, 460);
        d.setContentPane(Tema.scrollPane(form));
        d.getContentPane().setBackground(Tema.getBgDialog());
        d.setVisible(true);
    }

    /**
     * Abre o formulário de abertura de novo chamado.
     *
     * Valida que os campos obrigatórios (assunto e descrição) foram preenchidos
     * antes de submeter. Os combos são populados com os dados atuais do serviço
     * no momento em que o dialog é aberto.
     */
    private void abrirFormularioNovoChamado() {
        JDialog d = novoDialog("Novo Chamado", 500, 540);
        JPanel form = dialogPanel();
        GridBagConstraints g = gbc();

        JTextField txtAssunto = Tema.campo();
        JTextArea  taDesc     = Tema.areaTexto(4);

        JComboBox<Prioridade> cbPrio  = Tema.combo();
        JComboBox<Object>     cbSolic = Tema.combo();
        JComboBox<Object>     cbEquip = Tema.combo();
        JComboBox<Object>     cbSetor = Tema.combo();

        for (Prioridade p : Prioridade.values()) cbPrio.addItem(p);
        service.getListaUsuarios().forEach(cbSolic::addItem);
        cbEquip.addItem("(nenhum)");
        service.getListaEquipamentos().forEach(cbEquip::addItem);
        service.getListaSetores().forEach(cbSetor::addItem);

        String[]    labels = {"Assunto *", "Descricao *", "Prioridade *", "Solicitante *", "Equipamento", "Setor *"};
        Component[] fields = {txtAssunto, Tema.scrollPane(taDesc), cbPrio, cbSolic, cbEquip, cbSetor};

        for (int i = 0; i < labels.length; i++) {
            g.gridy  = i * 2;
            g.insets = new Insets(i == 0 ? 0 : 10, 0, 0, 0);
            form.add(dialogLabel(labels[i]), g);

            g.gridy  = i * 2 + 1;
            g.insets = new Insets(4, 0, 0, 0);
            if (fields[i] instanceof JScrollPane) {
                ((JScrollPane) fields[i]).setPreferredSize(new Dimension(0, 80));
            } else {
                fields[i].setPreferredSize(new Dimension(0, 36));
            }
            form.add(fields[i], g);
        }

        g.gridy  = labels.length * 2;
        g.insets = new Insets(20, 0, 0, 0);

        JButton cancel = Tema.botaoSecundario("Cancelar");
        JButton abrir  = Tema.botaoPrimario("Abrir Chamado");

        cancel.addActionListener(e -> d.dispose());
        abrir.addActionListener(e -> {
            // Validação dos campos obrigatórios antes de criar o chamado
            if (txtAssunto.getText().trim().isEmpty() || taDesc.getText().trim().isEmpty()) {
                alerta("Preencha Assunto e Descricao.");
                return;
            }
            service.abrirChamado(
                txtAssunto.getText(),
                taDesc.getText(),
                (Prioridade) cbPrio.getSelectedItem(),
                cbSolic.getSelectedItem() instanceof Usuario  u  ? u  : null,
                cbEquip.getSelectedItem() instanceof Equipamento eq ? eq : null,
                cbSetor.getSelectedItem() instanceof Setor     s  ? s  : null
            );
            janela.atualizarTudo();
            atualizar();
            d.dispose();
        });
        form.add(btnRowPanel(cancel, abrir), g);

        d.setContentPane(Tema.scrollPane(form));
        d.getContentPane().setBackground(Tema.getBgDialog());
        d.setVisible(true);
    }

    /**
     * Exibe um dialog de aviso simples com a mensagem informada.
     * Usa o mesmo padrão visual do alerta global do Tema.
     *
     * @param msg mensagem a ser exibida ao usuário
     */
    private void alerta(String msg) {
        Tema.alerta(janela, msg);
    }

    /**
     * Recarrega a tabela com todos os chamados e limpa o campo de busca.
     * Chamado ao navegar para este painel e após cada operação de alteração.
     */
    public void atualizar() {
        preencherTabela(service.getListaTodosChamados());
    }
}
