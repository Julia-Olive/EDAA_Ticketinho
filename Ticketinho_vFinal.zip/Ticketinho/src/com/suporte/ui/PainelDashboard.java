package com.suporte.ui;

import com.suporte.model.*;
import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * Painel de visão geral do sistema Ticketinho.
 *
 * Exibe quatro KPIs principais no topo e duas tabelas abaixo:
 * a fila de espera (chamados ABERTOS aguardando técnico) e os chamados
 * ativos ordenados por prioridade.
 *
 * O painel é atualizado automaticamente sempre que o usuário navega
 * até ele ou realiza uma ação em outro painel que chame {@code atualizarTudo()}.
 */
public class PainelDashboard extends JPanel {

    private final SupportService service;
    private final JanelaPrincipal janela;

    // Labels dos KPIs; atualizados em atualizar() sem recriar os componentes
    private JLabel valAbertos, valAtendimento, valHistorico, valCriticos;

    // Modelos das tabelas; resetados a cada atualização
    private DefaultTableModel mdlFila, mdlAtivos;

    /**
     * Cria o painel e monta a estrutura visual inicial.
     *
     * @param service serviço de suporte compartilhado
     * @param janela  referência para a janela principal (navegação)
     */
    public PainelDashboard(SupportService service, JanelaPrincipal janela) {
        this.service = service;
        this.janela  = janela;
        setBackground(Tema.getBgApp());
        setLayout(new BorderLayout(0, 0));
        construir();
    }

    /**
     * Monta a estrutura visual do painel: header, linha de KPIs e tabelas.
     * Chamado apenas uma vez no construtor; os dados sao populados por atualizar().
     */
    private void construir() {
        // Header com título e botão de atualização manual
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Tema.getBgApp());
        header.setBorder(new EmptyBorder(28, 28, 16, 28));

        JLabel titulo = new JLabel("Visao Geral");
        titulo.setFont(Tema.FONTE_TITULO);
        titulo.setForeground(Tema.getTextoPrimario());

        JLabel subtitulo = new JLabel("Resumo do sistema de suporte");
        subtitulo.setFont(Tema.FONTE_BODY);
        subtitulo.setForeground(Tema.getTextoSecundario());

        JPanel tituloBox = new JPanel();
        tituloBox.setLayout(new BoxLayout(tituloBox, BoxLayout.Y_AXIS));
        tituloBox.setBackground(Tema.getBgApp());
        tituloBox.add(titulo);
        tituloBox.add(Box.createVerticalStrut(4));
        tituloBox.add(subtitulo);
        header.add(tituloBox, BorderLayout.WEST);

        JButton btnAtualizar = Tema.botaoSecundario("Atualizar");
        btnAtualizar.addActionListener(e -> atualizar());
        header.add(btnAtualizar, BorderLayout.EAST);

        // Linha de KPIs com quatro cards
        JPanel kpiRow = new JPanel(new GridLayout(1, 4, 14, 0));
        kpiRow.setBackground(Tema.getBgApp());
        kpiRow.setBorder(new EmptyBorder(0, 28, 20, 28));

        valAbertos     = new JLabel("0", SwingConstants.CENTER);
        valAtendimento = new JLabel("0", SwingConstants.CENTER);
        valHistorico   = new JLabel("0", SwingConstants.CENTER);
        valCriticos    = new JLabel("0", SwingConstants.CENTER);

        kpiRow.add(criarKpi("Abertos",         valAbertos,     Tema.STATUS_AZUL,     "Abertos"));
        kpiRow.add(criarKpi("Em Atendimento",  valAtendimento, Tema.STATUS_AMARELO,  "Em andamento"));
        kpiRow.add(criarKpi("No Historico",    valHistorico,   Tema.STATUS_VERDE,    "Encerrados"));
        kpiRow.add(criarKpi("Criticos Ativos", valCriticos,    Tema.STATUS_VERMELHO, "Urgentes"));

        // Linha de tabelas: fila de espera e ativos por prioridade
        JPanel tablesRow = new JPanel(new GridLayout(1, 2, 14, 0));
        tablesRow.setBackground(Tema.getBgApp());
        tablesRow.setBorder(new EmptyBorder(0, 28, 28, 28));

        mdlFila = new DefaultTableModel(
                new String[]{"#", "Assunto", "Prioridade", "Solicitante", "Abertura"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tblFila = criarTabela(mdlFila);
        tablesRow.add(criarCardTabela("Fila de Espera", tblFila));

        mdlAtivos = new DefaultTableModel(
                new String[]{"#", "Assunto", "Status", "Setor"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tblAtivos = criarTabela(mdlAtivos);
        tablesRow.add(criarCardTabela("Ativos por Prioridade", tblAtivos));

        JPanel corpo = new JPanel(new BorderLayout(0, 0));
        corpo.setBackground(Tema.getBgApp());
        corpo.add(kpiRow, BorderLayout.NORTH);
        corpo.add(tablesRow, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(corpo, BorderLayout.CENTER);
    }

    /**
     * Cria um card de KPI com número grande, cor de destaque e rótulo.
     *
     * A barra colorida no topo do card e desenhada em Java2D via paintComponent
     * customizado para criar um efeito visual sem usar imagens.
     *
     * @param label  rótulo descritivo do indicador
     * @param valor  label que será atualizado com o número em atualizar()
     * @param cor    cor de destaque do KPI
     * @param icone  texto alternativo breve exibido no canto superior esquerdo
     * @return painel do card KPI
     */
    private JPanel criarKpi(String label, JLabel valor, Color cor, String icone) {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Tema.getBgCard());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(Tema.getBorda());
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 12, 12));
                // Barra de cor no topo identifica o KPI visualmente
                g2.setColor(cor);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), 4, 4, 4));
                g2.dispose();
            }
        };
        card.setLayout(new BorderLayout(0, 4));
        card.setBackground(Tema.getBgCard());
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel ico = new JLabel(icone);
        ico.setFont(Tema.FONTE_SMALL);
        ico.setForeground(cor);

        valor.setFont(Tema.FONTE_KPI);
        valor.setForeground(cor);

        JLabel lbl = new JLabel(label);
        lbl.setFont(Tema.FONTE_SMALL);
        lbl.setForeground(Tema.getTextoSecundario());
        lbl.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Tema.getBgCard());
        top.setOpaque(false);
        top.add(ico, BorderLayout.WEST);

        card.add(top, BorderLayout.NORTH);
        card.add(valor, BorderLayout.CENTER);
        card.add(lbl, BorderLayout.SOUTH);
        return card;
    }

    /**
     * Envolve uma tabela em um card com título e borda arredondada.
     *
     * @param titulo texto do cabecalho do card
     * @param tabela tabela a ser exibida dentro do card
     * @return painel do card com a tabela
     */
    private JPanel criarCardTabela(String titulo, JTable tabela) {
        JPanel card = new JPanel(new BorderLayout(0, 12)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Tema.getBgCard());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(Tema.getBorda());
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 12, 12));
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel lbl = new JLabel(titulo);
        lbl.setFont(Tema.FONTE_SUBTITULO);
        lbl.setForeground(Tema.getTextoPrimario());
        lbl.setBorder(new EmptyBorder(0, 0, 8, 0));

        card.add(lbl, BorderLayout.NORTH);
        card.add(Tema.scrollPane(tabela), BorderLayout.CENTER);
        return card;
    }

    /**
     * Cria uma tabela estilizada com renderizadores de prioridade e linhas alternadas.
     *
     * O renderizador da coluna Prioridade aplica a cor semântica ao texto
     * para diferenciar visualmente os níveis de urgência.
     *
     * @param model modelo de dados da tabela
     * @return tabela estilizada pronta para uso
     */
    private JTable criarTabela(DefaultTableModel model) {
        JTable tabela = new JTable(model) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                c.setBackground(row % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                c.setForeground(Tema.getTextoPrimario());
                if (isRowSelected(row)) c.setBackground(Tema.getSelecaoSolida());
                return c;
            }
        };
        tabela.setFont(Tema.FONTE_BODY);
        tabela.setRowHeight(36);
        tabela.setShowGrid(false);
        tabela.setIntercellSpacing(new Dimension(0, 1));
        tabela.setSelectionBackground(Tema.getSelecaoSolida());
        tabela.setSelectionForeground(Tema.getTextoPrimario());
        tabela.setFocusable(false);

        JTableHeader header = tabela.getTableHeader();
        header.setBackground(Tema.getBgSidebar());
        header.setForeground(Tema.getTextoMuted());
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        header.setReorderingAllowed(false);

        // Renderer especial para a coluna Prioridade: texto colorido conforme o nivel
        DefaultTableCellRenderer rendPrio = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                String txt = v != null ? v.toString() : "";
                setForeground(Tema.corPrioridade(txt));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 8, 0, 8));
                setBackground(r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                if (sel) setBackground(Tema.getSelecaoSolida());
                return this;
            }
        };

        DefaultTableCellRenderer rendPad = new DefaultTableCellRenderer();
        rendPad.setBorder(new EmptyBorder(0, 8, 0, 8));

        for (int i = 0; i < model.getColumnCount(); i++) {
            String col = model.getColumnName(i);
            if (col.equals("Prioridade")) {
                tabela.getColumnModel().getColumn(i).setCellRenderer(rendPrio);
            } else {
                tabela.getColumnModel().getColumn(i).setCellRenderer(rendPad);
            }
        }

        return tabela;
    }

    /**
     * Recalcula os KPIs e popula as tabelas com os dados atuais do serviço.
     *
     * Chamado automaticamente ao navegar para este painel e manualmente
     * pelo botão "Atualizar".
     */
    public void atualizar() {
        List<Chamado> todos = service.getListaTodosChamados();

        long abertos  = todos.stream().filter(c -> c.getStatus() == Status.ABERTO).count();
        long emAten   = todos.stream().filter(c -> c.getStatus() == Status.EM_ATENDIMENTO).count();
        long criticos = todos.stream()
                .filter(c -> c.getStatus() == Status.ABERTO && c.getPrioridade() == Prioridade.CRITICA)
                .count();
        long hist = service.getPilhaHistorico().getTamanho();

        valAbertos.setText(String.valueOf(abertos));
        valAtendimento.setText(String.valueOf(emAten));
        valHistorico.setText(String.valueOf(hist));
        valCriticos.setText(String.valueOf(criticos));

        // Popula a fila de espera com os chamados ainda não atendidos
        mdlFila.setRowCount(0);
        todos.stream()
             .filter(c -> c.getStatus() == Status.ABERTO)
             .forEach(c -> mdlFila.addRow(new Object[]{
                 String.format("#%04d", c.getId()),
                 c.getAssunto(),
                 c.getPrioridade().toString(),
                 c.getSolicitante() != null ? c.getSolicitante().getNome() : "-",
                 c.getDataAberturaFormatada()
             }));

        // Popula os ativos por prioridade (abertos e em atendimento)
        mdlAtivos.setRowCount(0);
        service.listarChamadosOrdenadosPorPrioridade().stream()
               .filter(c -> c.getStatus() == Status.ABERTO || c.getStatus() == Status.EM_ATENDIMENTO)
               .forEach(c -> mdlAtivos.addRow(new Object[]{
                   String.format("#%04d", c.getId()),
                   c.getAssunto(),
                   c.getStatus().toString(),
                   c.getSetor() != null ? c.getSetor().getNome() : "-"
               }));
    }
}
