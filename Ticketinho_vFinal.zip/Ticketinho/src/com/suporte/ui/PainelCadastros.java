package com.suporte.ui;

import com.suporte.model.*;
import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;

/**
 * Painel de cadastros do Ticketinho.
 *
 * Organiza em abas o CRUD de três entidades: usuários, equipamentos e setores.
 * Cada aba tem sua própria tabela e botão de inclusão. A exclusão não foi
 * implementada intencionalmente, pois deletar usuarios ou equipamentos com
 * chamados vinculados geraria inconsistências nos dados.
 *
 * Após cada inclusão bem-sucedida, {@code atualizar()} é chamado para
 * refletir o novo dado em todas as três tabelas imediatamente.
 */
public class PainelCadastros extends JPanel {

    private final SupportService service;
    private final JanelaPrincipal janela;

    // Modelos das três tabelas; atualizados juntos em atualizar()
    private DefaultTableModel mdlUsuarios, mdlEquipamentos, mdlSetores;

    /**
     * Cria o painel e monta a estrutura visual com as três abas.
     *
     * @param service serviço de suporte compartilhado
     * @param janela  referência para a janela principal
     */
    public PainelCadastros(SupportService service, JanelaPrincipal janela) {
        this.service = service;
        this.janela  = janela;
        setBackground(Tema.getBgApp());
        setLayout(new BorderLayout(0, 0));
        construir();
    }

    /**
     * Monta o header com título e o JTabbedPane com as três abas de cadastro.
     */
    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Tema.getBgApp());
        header.setBorder(new EmptyBorder(28, 28, 16, 28));

        JLabel titulo = new JLabel("Cadastros");
        titulo.setFont(Tema.FONTE_TITULO);
        titulo.setForeground(Tema.getTextoPrimario());
        header.add(titulo, BorderLayout.WEST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(Tema.getBgCard());
        tabs.setForeground(Tema.getTextoPrimario());
        tabs.setFont(Tema.FONTE_BOLD);
        tabs.setBorder(BorderFactory.createEmptyBorder());

        tabs.addTab("Usuarios",     criarAbaUsuarios());
        tabs.addTab("Equipamentos", criarAbaEquipamentos());
        tabs.addTab("Setores",      criarAbaSetores());

        JPanel corpo = new JPanel(new BorderLayout());
        corpo.setBackground(Tema.getBgApp());
        corpo.setBorder(new EmptyBorder(0, 28, 28, 28));
        corpo.add(tabs);

        add(header, BorderLayout.NORTH);
        add(corpo, BorderLayout.CENTER);
    }

    /**
     * Cria a aba de usuários com tabela e botão de inclusão.
     * As colunas exibem todos os dados relevantes, incluindo o perfil
     * (Técnico ou Usuário) para facilitar a identificação rápida.
     *
     * @return painel da aba de usuarios
     */
    private JPanel criarAbaUsuarios() {
        mdlUsuarios = new DefaultTableModel(
                new String[]{"#", "Nome", "E-mail", "Telefone", "Setor", "Perfil"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = criarTabela(mdlUsuarios);

        JButton btnNovo = Tema.botaoPrimario("+ Usuario");
        btnNovo.addActionListener(e -> dialogNovoUsuario());

        return montarPainelTab(tbl, btnNovo);
    }

    /**
     * Cria a aba de equipamentos com tabela e botão de inclusão.
     *
     * @return painel da aba de equipamentos
     */
    private JPanel criarAbaEquipamentos() {
        mdlEquipamentos = new DefaultTableModel(
                new String[]{"#", "Nome", "Tipo", "Patrimonio", "Setor"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = criarTabela(mdlEquipamentos);

        JButton btnNovo = Tema.botaoPrimario("+ Equipamento");
        btnNovo.addActionListener(e -> dialogNovoEquipamento());

        return montarPainelTab(tbl, btnNovo);
    }

    /**
     * Cria a aba de setores com tabela e botão de inclusão.
     *
     * @return painel da aba de setores
     */
    private JPanel criarAbaSetores() {
        mdlSetores = new DefaultTableModel(
                new String[]{"#", "Descricao"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = criarTabela(mdlSetores);

        JButton btnNovo = Tema.botaoPrimario("+ Setor");
        btnNovo.addActionListener(e -> dialogNovoSetor());

        return montarPainelTab(tbl, btnNovo);
    }

    /**
     * Monta o layout padrão de uma aba: toolbar com botão de inclusão no topo
     * e tabela no centro.
     *
     * @param tbl    tabela de dados da aba
     * @param btnNovo botão de inclusão a ser exibido na toolbar
     * @return painel da aba montado
     */
    private JPanel montarPainelTab(JTable tbl, JButton btnNovo) {
        JPanel painel = new JPanel(new BorderLayout(0, 0));
        painel.setBackground(Tema.getBgDialog());

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        topBar.setBackground(Tema.getBgCard());
        topBar.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        topBar.add(btnNovo);

        painel.add(topBar, BorderLayout.NORTH);
        painel.add(Tema.scrollPane(tbl), BorderLayout.CENTER);
        return painel;
    }

    /**
     * Cria uma tabela estilizada genérica para uso nas três abas.
     * Todas as células são somente leitura.
     *
     * @param model modelo de dados da tabela
     * @return tabela estilizada
     */
    private JTable criarTabela(DefaultTableModel model) {
        JTable t = new JTable(model) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                boolean sel = isRowSelected(row);
                c.setBackground(sel ? Tema.getSelecaoSolida()
                               : row % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                c.setForeground(Tema.getTextoPrimario());
                return c;
            }
        };
        t.setFont(Tema.FONTE_BODY);
        t.setRowHeight(38);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 1));

        JTableHeader header = t.getTableHeader();
        header.setBackground(Tema.getBgSidebar());
        header.setForeground(Tema.getTextoMuted());
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        header.setReorderingAllowed(false);

        DefaultTableCellRenderer rend = new DefaultTableCellRenderer() {
            { setBorder(new EmptyBorder(0, 12, 0, 12)); }
        };
        for (int i = 0; i < model.getColumnCount(); i++) {
            t.getColumnModel().getColumn(i).setCellRenderer(rend);
        }

        return t;
    }

    // ----- Dialogs de inclusão -----

    /**
     * Abre o dialog de inclusão de novo usuario.
     *
     * O checkbox "É técnico de TI?" determina se o usuario aparece como
     * opção para atribuição de chamados. O campo de setor usa os setores
     * já cadastrados no sistema.
     */
    private void dialogNovoUsuario() {
        JDialog dlg = new JDialog(janela, "Novo Usuario", true);
        dlg.setSize(520, 480);
        dlg.setLocationRelativeTo(janela);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Tema.getBgDialog());
        form.setBorder(new EmptyBorder(20, 24, 20, 24));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill    = GridBagConstraints.HORIZONTAL;
        gbc.insets  = new Insets(5, 0, 5, 0);
        gbc.weightx = 1.0;

        JTextField tfNome  = Tema.campo();
        JTextField tfEmail = Tema.campo();
        JTextField tfTel   = Tema.campo();
        JComboBox<Object> cbSetor = Tema.combo();

        JCheckBox chkTecnico = new JCheckBox("E tecnico de TI?");
        chkTecnico.setFont(Tema.FONTE_BODY);
        chkTecnico.setForeground(Tema.getTextoPrimario());
        chkTecnico.setBackground(Tema.getBgDialog());

        service.getListaSetores().forEach(cbSetor::addItem);

        String[]    labels = {"Nome:", "E-mail:", "Telefone:", "Setor:"};
        Component[] fields = {tfNome, tfEmail, tfTel, cbSetor};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridy = i * 2; gbc.gridx = 0;
            JLabel l = new JLabel(labels[i]);
            l.setFont(Tema.FONTE_BOLD);
            l.setForeground(Tema.getTextoSecundario());
            form.add(l, gbc);

            gbc.gridy = i * 2 + 1;
            form.add(fields[i], gbc);
        }

        gbc.gridy = labels.length * 2;
        form.add(chkTecnico, gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Tema.getBgDialog());

        JButton btnCancel = Tema.botaoSecundario("Cancelar");
        JButton btnSalvar = Tema.botaoPrimario("Salvar");

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSalvar.addActionListener(e -> {
            if (tfNome.getText().trim().isEmpty()) {
                Tema.alerta(dlg, "Informe o nome.");
                return;
            }
            Object sel = cbSetor.getSelectedItem();
            service.cadastrarUsuario(
                tfNome.getText(), tfEmail.getText(), tfTel.getText(),
                (sel instanceof Setor) ? (Setor) sel : null,
                chkTecnico.isSelected()
            );
            atualizar();
            dlg.dispose();
        });

        btnRow.add(btnCancel);
        btnRow.add(btnSalvar);

        gbc.gridy  = labels.length * 2 + 1;
        gbc.insets = new Insets(12, 0, 0, 0);
        form.add(btnRow, gbc);

        dlg.setContentPane(form);
        dlg.getContentPane().setBackground(Tema.getBgDialog());
        dlg.setVisible(true);
    }

    /**
     * Abre o dialog de inclusão de novo equipamento.
     *
     * O número de patrimônio identifica o bem no inventário físico
     * da empresa e é exibido em um campo separado do nome.
     */
    private void dialogNovoEquipamento() {
        JDialog dlg = new JDialog(janela, "Novo Equipamento", true);
        dlg.setSize(460, 420);
        dlg.setLocationRelativeTo(janela);
        dlg.setResizable(false);

        // Header interno do dialog com estilo de sidebar
        JPanel dlgHeader = new JPanel(new BorderLayout());
        dlgHeader.setBackground(Tema.getBgSidebar());
        dlgHeader.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0, 0, 1, 0, Tema.getBorda()),
                new EmptyBorder(16, 24, 16, 24)));

        JLabel dlgTitulo = new JLabel("Novo Equipamento");
        dlgTitulo.setFont(Tema.FONTE_SUBTITULO);
        dlgTitulo.setForeground(Tema.getTextoPrimario());
        dlgHeader.add(dlgTitulo, BorderLayout.WEST);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Tema.getBgDialog());
        form.setBorder(new EmptyBorder(20, 24, 12, 24));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill    = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JTextField tfNome = Tema.campo();
        JTextField tfTipo = Tema.campo();
        JTextField tfPat  = Tema.campo();
        JComboBox<Object> cbSetor = Tema.combo();
        service.getListaSetores().forEach(cbSetor::addItem);

        String[]    labels = {"Nome:", "Tipo:", "Patrimonio:", "Setor:"};
        Component[] fields = {tfNome, tfTipo, tfPat, cbSetor};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridy  = i * 2; gbc.gridx = 0;
            gbc.insets = new Insets(i == 0 ? 0 : 12, 0, 4, 0);
            JLabel l = new JLabel(labels[i]);
            l.setFont(Tema.FONTE_BOLD);
            l.setForeground(Tema.getTextoSecundario());
            form.add(l, gbc);

            gbc.gridy  = i * 2 + 1;
            gbc.insets = new Insets(0, 0, 0, 0);
            form.add(fields[i], gbc);
        }

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 12));
        footer.setBackground(Tema.getBgDialog());
        footer.setBorder(new MatteBorder(1, 0, 0, 0, Tema.getBorda()));

        JButton btnCancel = Tema.botaoSecundario("Cancelar");
        JButton btnSalvar = Tema.botaoPrimario("Salvar");

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSalvar.addActionListener(e -> {
            if (tfNome.getText().trim().isEmpty()) {
                Tema.alerta(dlg, "Informe o nome.");
                return;
            }
            Object sel = cbSetor.getSelectedItem();
            service.cadastrarEquipamento(
                tfNome.getText(), tfTipo.getText(), tfPat.getText(),
                (sel instanceof Setor) ? (Setor) sel : null
            );
            atualizar();
            dlg.dispose();
        });

        footer.add(btnCancel);
        footer.add(btnSalvar);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Tema.getBgDialog());
        root.add(dlgHeader, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);

        dlg.setContentPane(root);
        dlg.setVisible(true);
    }

    /**
     * Abre o dialog de inclusão de novo setor.
     *
     * O formulário é reduzido: apenas o nome do setor é necessário.
     */
    private void dialogNovoSetor() {
        JDialog dlg = new JDialog(janela, "Novo Setor", true);
        dlg.setSize(380, 200);
        dlg.setLocationRelativeTo(janela);
        dlg.setResizable(false);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Tema.getBgDialog());
        form.setBorder(new EmptyBorder(20, 24, 20, 24));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill    = GridBagConstraints.HORIZONTAL;
        gbc.insets  = new Insets(5, 0, 5, 0);
        gbc.weightx = 1.0;

        JLabel lbl = new JLabel("Descricao:");
        lbl.setFont(Tema.FONTE_BOLD);
        lbl.setForeground(Tema.getTextoSecundario());
        gbc.gridy = 0;
        form.add(lbl, gbc);

        JTextField tfNome = Tema.campo();
        gbc.gridy = 1;
        form.add(tfNome, gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Tema.getBgDialog());

        JButton btnCancel = Tema.botaoSecundario("Cancelar");
        JButton btnSalvar = Tema.botaoPrimario("Salvar");

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSalvar.addActionListener(e -> {
            if (tfNome.getText().trim().isEmpty()) {
                Tema.alerta(dlg, "Informe a descricao.");
                return;
            }
            service.cadastrarSetor(tfNome.getText());
            atualizar();
            dlg.dispose();
        });

        btnRow.add(btnCancel);
        btnRow.add(btnSalvar);

        gbc.gridy  = 2;
        gbc.insets = new Insets(14, 0, 0, 0);
        form.add(btnRow, gbc);

        dlg.setContentPane(form);
        dlg.setVisible(true);
    }

    /**
     * Recarrega as três tabelas com os dados atuais do serviço.
     * Chamado ao navegar para este painel e aps cada inclusão.
     */
    public void atualizar() {
        // Usuários
        mdlUsuarios.setRowCount(0);
        service.getListaUsuarios().forEach(u -> mdlUsuarios.addRow(new Object[]{
            u.getId(), u.getNome(), u.getEmail(), u.getTelefone(),
            u.getSetor() != null ? u.getSetor().getNome() : "-",
            u.isTecnico() ? "Tecnico" : "Usuario"
        }));

        // Equipamentos
        mdlEquipamentos.setRowCount(0);
        service.getListaEquipamentos().forEach(e -> mdlEquipamentos.addRow(new Object[]{
            e.getId(), e.getNome(), e.getTipo(), e.getPatrimonio(),
            e.getSetor() != null ? e.getSetor().getNome() : "-"
        }));

        // Setores
        mdlSetores.setRowCount(0);
        service.getListaSetores().forEach(s -> mdlSetores.addRow(new Object[]{
            s.getId(), s.getNome()
        }));
    }
}
