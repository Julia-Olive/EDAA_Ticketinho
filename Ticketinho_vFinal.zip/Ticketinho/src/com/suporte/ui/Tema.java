package com.suporte.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Sistema de tema visual do Ticketinho.
 *
 * Centraliza todas as decisões de cor, fonte e estilo de componentes.
 * Nenhum painel deve definir cores ou fontes diretamente; eles devem
 * consultar os métodos e constantes desta classe. Isso garante que trocar
 * de modo escuro para claro (e vice-versa) afete toda a interface de uma só vez.
 *
 * Os métodos que retornam Color s~so dinâmicos (por exemplo, getBgApp()) e
 * levam em conta o modo atual. As constantes estáticas como AMBAR não mudam
 * entre modos.
 *
 * Os métodos factory (botaoPrimario, campo, etc.) criam componentes Swing
 * já estilizados, evitando que o mesmo código de configuração visual seja
 * repetido em vários paineis.
 */
public class Tema {

    // Modo atual da interface; começa escuro por padrão
    private static boolean modoEscuro = true;

    public static boolean isModoEscuro() { return modoEscuro; }

    /**
     * Alterna entre modo escuro e claro e reaplicar as configurações do UIManager.
     * O método é chamado pelo botão de alternância na sidebar.
     */
    public static void alternarModo() {
        modoEscuro = !modoEscuro;
        aplicarUIManager();
    }

    // Cores de fundo dinâmicas: cada método devolve a cor correta para o modo atual

    public static Color getBgApp()     { return modoEscuro ? new Color(0x0F,0x11,0x17) : new Color(0xF1,0xF3,0xF9); }
    public static Color getBgSidebar() { return modoEscuro ? new Color(0x16,0x18,0x22) : new Color(0xFF,0xFF,0xFF); }
    public static Color getBgCard()    { return modoEscuro ? new Color(0x1C,0x1F,0x2E) : new Color(0xFF,0xFF,0xFF); }
    public static Color getBgRowAlt()  { return modoEscuro ? new Color(0x20,0x23,0x33) : new Color(0xF6,0xF8,0xFF); }
    public static Color getBgInput()   { return modoEscuro ? new Color(0x12,0x14,0x1E) : new Color(0xF8,0xF9,0xFF); }
    public static Color getBgHover()   { return modoEscuro ? new Color(0x22,0x25,0x38) : new Color(0xEA,0xED,0xF8); }
    public static Color getBgDialog()  { return modoEscuro ? new Color(0x18,0x1B,0x28) : new Color(0xFF,0xFF,0xFF); }

    // Cores de texto dinâmicas

    public static Color getTextoPrimario()   { return modoEscuro ? new Color(0xF0,0xF4,0xFF) : new Color(0x10,0x12,0x1A); }
    public static Color getTextoSecundario() { return modoEscuro ? new Color(0x8A,0x9B,0xBB) : new Color(0x48,0x54,0x70); }
    public static Color getTextoMuted()      { return modoEscuro ? new Color(0x45,0x4F,0x65) : new Color(0x90,0x9D,0xB5); }
    public static Color getBorda()           { return modoEscuro ? new Color(0x2A,0x2F,0x46) : new Color(0xD8,0xDE,0xEE); }

    // Selecao visível nos dois modos; usa alpha para não cobrir completamente o texto
    public static Color getSelecao()       { return modoEscuro ? new Color(0xF5,0xA6,0x23,60)  : new Color(0xF5,0xA6,0x23,100); }
    public static Color getSelecaoSolida() { return modoEscuro ? new Color(0x3A,0x30,0x12)      : new Color(0xFF,0xEC,0xC0); }

    // Cores de destaque para status e prioridade; não mudam entre modos

    public static final Color AMBAR          = new Color(0xF5,0xA6,0x23);
    public static final Color AMBAR_ESCURO   = new Color(0xD4,0x88,0x0A);
    public static final Color STATUS_AZUL    = new Color(0x3B,0x82,0xF6);
    public static final Color STATUS_AMARELO = new Color(0xF5,0xA6,0x23);
    public static final Color STATUS_VERDE   = new Color(0x22,0xC5,0x5E);
    public static final Color STATUS_VERMELHO = new Color(0xEF,0x44,0x44);
    public static final Color STATUS_LARANJA = new Color(0xFB,0x77,0x3C);
    public static final Color STATUS_CINZA   = new Color(0x64,0x74,0x8B);

    // Fontes padronizadas para toda a interface

    public static final Font FONTE_TITULO    = new Font("Segoe UI", Font.BOLD,  22);
    public static final Font FONTE_SUBTITULO = new Font("Segoe UI", Font.BOLD,  14);
    public static final Font FONTE_BOLD      = new Font("Segoe UI", Font.BOLD,  13);
    public static final Font FONTE_BODY      = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONTE_SMALL     = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONTE_MONO      = new Font("Consolas",  Font.PLAIN, 12);
    public static final Font FONTE_KPI       = new Font("Segoe UI", Font.BOLD,  34);
    public static final Font FONTE_BADGE     = new Font("Segoe UI", Font.BOLD,  10);

    // Aliases estáticos mantidos para compatibilidade com código legado da interface;
    // são atualizados em aplicarUIManager() sempre que o modo muda
    public static Color BG_APP, BG_SIDEBAR, BG_HEADER_BAR, BG_CARD, BG_ROW_ALT,
                        BG_INPUT, BG_HOVER, TEXTO_PRIMARIO, TEXTO_SECUNDARIO,
                        TEXTO_MUTED, TEXTO_AMBAR, BORDA;

    /**
     * Inicializa o look and feel do Swing e aplica o tema.
     * Deve ser chamado uma única vez, antes de criar qualquer janela.
     *
     * A preferência e pelo Nimbus porque ele permite personalizar mais
     * elementos do UIManager do que o look and feel do sistema operacional.
     */
    public static void init() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
        }
        aplicarUIManager();
    }

    /**
     * Sincroniza o UIManager com as cores do modo atual.
     *
     * Isso é necessário porque dialogs do Swing (JOptionPane, JFileChooser, etc.)
     * consultam o UIManager para definir suas cores, e não os componentes
     * customizados. Sem isso, os dialogs continuariam com o visual padrão do sistema.
     *
     * Também atualiza os aliases estáticos para que código que ainda referencia
     * BG_APP, TEXTO_PRIMARIO etc. continue funcionando após uma troca de modo.
     */
    public static void aplicarUIManager() {
        // Atualiza aliases estaticos
        BG_APP = getBgApp();   BG_SIDEBAR = getBgSidebar();   BG_HEADER_BAR = getBgSidebar();
        BG_CARD = getBgCard(); BG_ROW_ALT = getBgRowAlt();    BG_INPUT = getBgInput();
        BG_HOVER = getBgHover(); TEXTO_PRIMARIO = getTextoPrimario();
        TEXTO_SECUNDARIO = getTextoSecundario(); TEXTO_MUTED = getTextoMuted();
        TEXTO_AMBAR = AMBAR; BORDA = getBorda();

        Color bg   = getBgDialog();
        Color fg   = getTextoPrimario();
        Color bgIn = getBgInput();

        UIManager.put("OptionPane.background",         new ColorUIResource(bg));
        UIManager.put("OptionPane.messageForeground",  new ColorUIResource(fg));
        UIManager.put("Panel.background",              new ColorUIResource(bg));
        UIManager.put("Label.foreground",              new ColorUIResource(fg));
        UIManager.put("TextField.background",          new ColorUIResource(bgIn));
        UIManager.put("TextField.foreground",          new ColorUIResource(fg));
        UIManager.put("TextField.caretForeground",     new ColorUIResource(AMBAR));
        UIManager.put("TextArea.background",           new ColorUIResource(bgIn));
        UIManager.put("TextArea.foreground",           new ColorUIResource(fg));
        UIManager.put("ComboBox.background",           new ColorUIResource(bgIn));
        UIManager.put("ComboBox.foreground",           new ColorUIResource(fg));
        UIManager.put("ComboBox.selectionBackground",  new ColorUIResource(getBgHover()));
        UIManager.put("ComboBox.selectionForeground",  new ColorUIResource(fg));
        UIManager.put("ScrollPane.background",         new ColorUIResource(bg));
        UIManager.put("Viewport.background",           new ColorUIResource(bg));
        UIManager.put("Button.background",             new ColorUIResource(getBgCard()));
        UIManager.put("Button.foreground",             new ColorUIResource(fg));
        UIManager.put("Button.select",                 new ColorUIResource(getBgHover()));
        UIManager.put("CheckBox.background",           new ColorUIResource(bg));
        UIManager.put("CheckBox.foreground",           new ColorUIResource(fg));
        UIManager.put("Dialog.background",             new ColorUIResource(bg));
        UIManager.put("RootPane.background",           new ColorUIResource(bg));
        UIManager.put("Table.background",              new ColorUIResource(getBgCard()));
        UIManager.put("Table.foreground",              new ColorUIResource(fg));
        UIManager.put("Table.selectionBackground",     new ColorUIResource(getSelecaoSolida()));
        UIManager.put("Table.selectionForeground",     new ColorUIResource(fg));
        UIManager.put("Table.gridColor",               new ColorUIResource(getBorda()));
        UIManager.put("TableHeader.background",        new ColorUIResource(getBgSidebar()));
        UIManager.put("TableHeader.foreground",        new ColorUIResource(getTextoMuted()));
        UIManager.put("TabbedPane.background",         new ColorUIResource(getBgCard()));
        UIManager.put("TabbedPane.foreground",         new ColorUIResource(fg));
        UIManager.put("TabbedPane.selected",           new ColorUIResource(getBgCard()));
        UIManager.put("TabbedPane.contentAreaColor",   new ColorUIResource(getBgCard()));
    }

    /**
     * Reaplicar o tema em uma janela existente apos uma troca de modo.
     * O updateComponentTreeUI percorre todos os componentes da janela
     * e reaplica o look and feel atual.
     *
     * @param w janela a ser reestilizada
     */
    public static void reaplicarEmJanela(Window w) {
        aplicarUIManager();
        SwingUtilities.updateComponentTreeUI(w);
    }

    /**
     * Aplica o tema a um dialog antes de torná-lo visível.
     * Necessário porque dialogs criados com {@code new JDialog()} não
     * herdam automaticamente as customizações do UIManager feitas depois
     * que o LookAndFeel já foi definido.
     *
     * @param dlg o dialog a ser estilizado
     */
    public static void estilizarDialog(JDialog dlg) {
        aplicarUIManager();
        pintar(dlg.getContentPane());
        dlg.getContentPane().setBackground(getBgDialog());
        SwingUtilities.updateComponentTreeUI(dlg);
    }

    /**
     * Percorre recursivamente todos os componentes de um container e
     * aplica as cores do tema a cada tipo conhecido.
     *
     * Este método e necessário porque o UIManager não retroage em
     * componentes que já foram criados antes da mudança de modo.
     *
     * @param c componente raiz a partir do qual a pintura começa
     */
    private static void pintar(Component c) {
        if (c instanceof JPanel p) {
            p.setBackground(getBgDialog());
            p.setForeground(getTextoPrimario());
        }
        if (c instanceof JLabel l) {
            l.setForeground(getTextoPrimario());
        }
        if (c instanceof JTextArea ta) {
            ta.setBackground(getBgInput());
            ta.setForeground(getTextoPrimario());
            ta.setCaretColor(AMBAR);
        }
        if (c instanceof JTextField tf) {
            tf.setBackground(getBgInput());
            tf.setForeground(getTextoPrimario());
            tf.setCaretColor(AMBAR);
        }
        if (c instanceof JComboBox<?> cb) {
            cb.setBackground(getBgInput());
            cb.setForeground(getTextoPrimario());
        }
        if (c instanceof JScrollPane sp) {
            sp.setBackground(getBgDialog());
            sp.getViewport().setBackground(getBgInput());
            sp.setBorder(new LineBorder(getBorda(), 1, true));
        }
        if (c instanceof JCheckBox ch) {
            ch.setBackground(getBgDialog());
            ch.setForeground(getTextoPrimario());
        }

        // Desce recursivamente nos filhos do container
        if (c instanceof Container container) {
            for (Component filho : container.getComponents()) {
                pintar(filho);
            }
        }
    }

    // ----- Factory: botões -----

    /**
     * Cria um botão de ação principal com fundo ambar.
     * Usado para operações de confirmação: salvar, abrir, iniciar atendimento.
     *
     * O paintComponent customizado usa Graphics2D com antialiasing para
     * bordas arredondadas suaves, sem depender de imagens.
     *
     * @param texto rótulo do botão
     * @return botão estilizado pronto para uso
     */
    public static JButton botaoPrimario(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Muda o tom de ambar conforme o estado do botão
                Color bg = getModel().isPressed()  ? AMBAR_ESCURO
                         : getModel().isRollover() ? AMBAR.brighter()
                         : AMBAR;

                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setForeground(new Color(0x10, 0x12, 0x1A));
        btn.setFont(FONTE_BOLD);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(9, 18, 9, 18));
        btn.setOpaque(false);
        return btn;
    }

    /**
     * Cria um botão de ação secundária com borda fina e fundo do card.
     * Usado para ações de suporte como cancelar, voltar ou listar.
     *
     * @param texto rótulo do botão
     * @return botão estilizado pronto para uso
     */
    public static JButton botaoSecundario(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? getBgHover() : getBgCard());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setColor(getBorda());
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 10, 10));
                g2.dispose();
                super.paintComponent(g);
            }

            @Override public Color getForeground() { return getTextoPrimario(); }
        };
        btn.setForeground(getTextoPrimario());
        btn.setFont(FONTE_BOLD);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(8, 16, 8, 16));
        btn.setOpaque(false);
        return btn;
    }

    /**
     * Cria um botão de ação destrutiva com fundo vermelho.
     * Usado exclusivamente para ações irreversíveis: cancelar chamado.
     *
     * O alpha de 200 no estado normal suaviza o vermelho;
     * ao passar o mouse o botão fica vermelho pleno para reforçar a
     * seriedade da ação.
     *
     * @param texto rótulo do botão
     * @return botão de perigo estilizado
     */
    public static JButton botaoPerigo(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()
                        ? STATUS_VERMELHO.darker()
                        : new Color(STATUS_VERMELHO.getRed(), STATUS_VERMELHO.getGreen(), STATUS_VERMELHO.getBlue(), 200));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setForeground(Color.WHITE);
        btn.setFont(FONTE_BOLD);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(8, 16, 8, 16));
        btn.setOpaque(false);
        return btn;
    }

    // ----- Factory: campos de entrada -----

    /**
     * Cria um campo de texto estilizado com borda ambar ao ganhar foco.
     * O feedback visual de foco ajuda o usuário a saber qual campo esta ativo.
     *
     * @return campo de texto estilizado
     */
    public static JTextField campo() {
        JTextField tf = new JTextField();
        tf.setBackground(getBgInput());
        tf.setForeground(getTextoPrimario());
        tf.setCaretColor(AMBAR);
        tf.setFont(FONTE_BODY);
        tf.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(getBorda(), 1, true),
                new EmptyBorder(8, 12, 8, 12)));

        // Troca a borda para ambar quando o campo recebe foco
        tf.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(AMBAR, 1, true), new EmptyBorder(8, 12, 8, 12)));
            }
            @Override public void focusLost(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(getBorda(), 1, true), new EmptyBorder(8, 12, 8, 12)));
            }
        });
        return tf;
    }

    /**
     * Cria uma área de texto multi-linha com fonte mono para preservar
     * a formatação de descrições técnicas.
     *
     * @param linhas número de linhas visíveis
     * @return área de texto estilizada com quebra automática de linha
     */
    public static JTextArea areaTexto(int linhas) {
        JTextArea ta = new JTextArea(linhas, 0);
        ta.setBackground(getBgInput());
        ta.setForeground(getTextoPrimario());
        ta.setCaretColor(AMBAR);
        ta.setFont(FONTE_MONO);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(new EmptyBorder(8, 12, 8, 12));
        return ta;
    }

    /**
     * Cria um combo box vazio pronto para receber itens.
     * Os itens são adicionados pelos painéis de acordo com o contexto.
     *
     * @param <T> tipo dos itens do combo
     * @return combo box estilizado
     */
    public static <T> JComboBox<T> combo() {
        JComboBox<T> cb = new JComboBox<>();
        cb.setBackground(getBgInput());
        cb.setForeground(getTextoPrimario());
        cb.setFont(FONTE_BODY);
        cb.setBorder(new LineBorder(getBorda(), 1, true));
        return cb;
    }

    /**
     * Cria um scroll pane estilizado para envolver tabelas e áreas de texto.
     * Remove a borda padrão do Swing e aplica a scrollbar customizada.
     *
     * @param c componente a ser envolvido pelo scroll
     * @return scroll pane estilizado
     */
    public static JScrollPane scrollPane(Component c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBackground(getBgCard());
        sp.getViewport().setBackground(getBgCard());
        sp.setBorder(BorderFactory.createEmptyBorder());
        estilizarScrollBar(sp.getVerticalScrollBar());
        estilizarScrollBar(sp.getHorizontalScrollBar());
        return sp;
    }

    /**
     * Substitui a scrollbar padrão do Swing por uma versão minimalista
     * com thumb arredondado e sem os botões de incremento/decremento.
     *
     * @param sb a scrollbar a ser reestilizada
     */
    private static void estilizarScrollBar(JScrollBar sb) {
        sb.setBackground(getBgCard());
        sb.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = modoEscuro ? new Color(0x3A, 0x40, 0x60) : new Color(0xB8, 0xC4, 0xDC);
                trackColor = getBgCard();
            }

            // Remove os botões de seta da scrollbar para um visual mais limpo
            @Override protected JButton createDecreaseButton(int o) { return semDimensao(); }
            @Override protected JButton createIncreaseButton(int o) { return semDimensao(); }

            private JButton semDimensao() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }

            // Desenha o thumb com bordas arredondadas usando Graphics2D
            @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fill(new RoundRectangle2D.Float(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8));
                g2.dispose();
            }
        });
    }

    // ----- Dialog de alerta -----

    /**
     * Exibe um dialog de aviso modal com uma faixa ambar decorativa no topo
     * e um ícone de atencao. Substitui o JOptionPane padrão do Swing para
     * manter a consistÊncia visual com o resto do sistema.
     *
     * @param pai janela pai que vai bloquear enquanto o alerta for visível
     * @param msg texto da mensagem (suporta HTML basico)
     */
    public static void alerta(Window pai, String msg) {
        JDialog d = new JDialog(pai, "Atencao", java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        d.setSize(400, 165);
        d.setLocationRelativeTo(pai);
        d.setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(getBgDialog());

        // Faixa ambar decorativa no topo do dialog
        JPanel stripe = new JPanel();
        stripe.setBackground(AMBAR);
        stripe.setPreferredSize(new Dimension(1, 4));
        root.add(stripe, BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(14, 0));
        body.setBackground(getBgDialog());
        body.setBorder(new EmptyBorder(20, 22, 18, 22));

        JLabel icon = new JLabel("\u26A0");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        icon.setForeground(AMBAR);
        body.add(icon, BorderLayout.WEST);

        JLabel lbl = new JLabel("<html><body style='width:270px'>" + msg + "</body></html>");
        lbl.setFont(FONTE_BODY);
        lbl.setForeground(getTextoPrimario());
        body.add(lbl, BorderLayout.CENTER);
        root.add(body, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 8));
        footer.setBackground(getBgDialog());
        footer.setBorder(new MatteBorder(1, 0, 0, 0, getBorda()));

        JButton ok = botaoPrimario("OK");
        ok.addActionListener(e -> d.dispose());
        footer.add(ok);
        root.add(footer, BorderLayout.SOUTH);

        d.setContentPane(root);
        d.setVisible(true);
    }

    // ----- Helpers de cor contextual -----

    /**
     * Retorna a cor de destaque para uma prioridade dada como string.
     * Usado pelos renderizadores de tabela para colorir a coluna Prioridade.
     *
     * @param p texto da prioridade (ex: "Crítica")
     * @return cor correspondente a prioridade
     */
    public static Color corPrioridade(String p) {
        if ("Critica".equals(p)) return STATUS_VERMELHO;
        if ("Alta".equals(p))    return STATUS_LARANJA;
        if ("Media".equals(p))   return STATUS_AMARELO;
        return STATUS_VERDE;
    }

    /**
     * Retorna a cor de destaque para um status dado como string.
     * Usado pelos renderizadores de tabela para colorir a coluna Status.
     *
     * @param s texto do status (ex: "Em Atendimento")
     * @return cor correspondente ao status
     */
    public static Color corStatus(String s) {
        if ("Aberto".equals(s))          return STATUS_AZUL;
        if ("Em Atendimento".equals(s))  return STATUS_AMARELO;
        if ("Resolvido".equals(s))       return STATUS_VERDE;
        if ("Cancelado".equals(s))       return STATUS_VERMELHO;
        return STATUS_CINZA;
    }
}
