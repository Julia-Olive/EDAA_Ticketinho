package com.suporte.ui;

import com.suporte.model.*;
import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * Painel de busca de chamados do Ticketinho.
 *
 * Oferece duas modalidades de busca:
 *   - Por ID: usa a árvore binária de busca (O(log n)), eficiente para
 *     localizar um chamado específico quando o número é conhecido.
 *   - Por assunto: percorre a lista ligada inteira (O(n)), útil para
 *     busca por texto parcial quando o ID não é conhecido.
 *
 * O botão "Listar por Prioridade" exibe todos os chamados ordenados
 * por prioridade decrescente, o que é útil para triagem rápida.
 */
public class PainelBusca extends JPanel {

    private final SupportService service;
    private final JanelaPrincipal janela;
    private DefaultTableModel mdl;
    private JTextField txtId, txtAssunto;

    /**
     * Cria o painel e monta a estrutura visual inicial.
     *
     * @param service serviço de suporte compartilhado
     * @param janela  referência para a janela principal
     */
    public PainelBusca(SupportService service, JanelaPrincipal janela) {
        this.service = service;
        this.janela  = janela;
        setBackground(Tema.getBgApp());
        setLayout(new BorderLayout(0, 0));
        construir();
    }

    /**
     * Monta o header, o card de busca com os campos e botões, e a tabela
     * de resultados abaixo. O card de busca e a tabela são empilhados em
     * um BorderLayout vertical para que a tabela ocupe o espaço restante.
     */
    private void construir() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Tema.getBgApp());
        header.setBorder(new EmptyBorder(28, 28, 16, 28));

        JLabel titulo = new JLabel("Busca");
        titulo.setFont(Tema.FONTE_TITULO);
        titulo.setForeground(Tema.getTextoPrimario());
        header.add(titulo, BorderLayout.WEST);

        // Card de busca com campos em linha
        JPanel searchCard = new JPanel(new GridBagLayout());
        searchCard.setBackground(Tema.getBgCard());
        searchCard.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0, 28, 16, 28, Tema.getBgApp()),
                BorderFactory.createCompoundBorder(
                        new LineBorder(Tema.getBorda(), 1, true),
                        new EmptyBorder(16, 20, 16, 20))));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 12);
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Campo de busca por número do chamado
        JLabel lblId = new JLabel("Chamado No.");
        lblId.setFont(Tema.FONTE_BOLD);
        lblId.setForeground(Tema.getTextoSecundario());
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        searchCard.add(lblId, gbc);

        txtId = Tema.campo();
        txtId.setPreferredSize(new Dimension(120, 36));
        gbc.gridx = 1; gbc.weightx = 0.15;
        searchCard.add(txtId, gbc);

        // Campo de busca por texto do assunto
        JLabel lblAssunto = new JLabel("Assunto contem");
        lblAssunto.setFont(Tema.FONTE_BOLD);
        lblAssunto.setForeground(Tema.getTextoSecundario());
        gbc.gridx = 2; gbc.weightx = 0;
        searchCard.add(lblAssunto, gbc);

        txtAssunto = Tema.campo();
        gbc.gridx = 3; gbc.weightx = 1.0;
        searchCard.add(txtAssunto, gbc);

        JButton btnBuscar = Tema.botaoPrimario("Buscar");
        btnBuscar.addActionListener(e -> executarBusca());
        gbc.gridx = 4; gbc.weightx = 0;
        searchCard.add(btnBuscar, gbc);

        JButton btnListar = Tema.botaoSecundario("Listar por Prioridade");
        btnListar.addActionListener(e -> listarPorPrioridade());
        gbc.gridx = 5;
        searchCard.add(btnListar, gbc);

        // Tabela de resultados da busca
        mdl = new DefaultTableModel(
                new String[]{"#", "Assunto", "Prioridade", "Status", "Solicitante",
                             "Tecnico", "Setor", "Abertura", "Fechamento"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = criarTabela();

        JPanel corpo = new JPanel(new BorderLayout());
        corpo.setBackground(Tema.getBgCard());
        corpo.setBorder(new MatteBorder(0, 28, 28, 28, Tema.getBgApp()));

        JPanel inner = new JPanel(new BorderLayout());
        inner.setBackground(Tema.getBgCard());
        inner.setBorder(new LineBorder(Tema.getBorda(), 1, true));
        inner.add(Tema.scrollPane(tbl));
        corpo.add(inner);

        // Empilha o card de busca e a tabela em um único painel central
        JPanel full = new JPanel(new BorderLayout(0, 0));
        full.setBackground(Tema.getBgApp());
        full.add(searchCard, BorderLayout.NORTH);
        full.add(corpo, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(full, BorderLayout.CENTER);
    }

    /**
     * Cria a tabela de resultados de busca com renderizadores coloridos
     * para as colunas Prioridade e Status.
     *
     * @return tabela estilizada pronta para uso
     */
    private JTable criarTabela() {
        JTable t = new JTable(mdl) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                boolean sel = isRowSelected(row);
                c.setBackground(sel ? Tema.getSelecaoSolida()
                               : row % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                c.setForeground(Tema.getTextoPrimario());
                return c;
            }
        };
        t.setFont(Tema.FONTE_BODY);
        t.setRowHeight(38);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 1));

        JTableHeader header = t.getTableHeader();
        header.setBackground(Tema.getBgSidebar());
        header.setForeground(Tema.getTextoMuted());
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        header.setReorderingAllowed(false);

        DefaultTableCellRenderer rendPad = new DefaultTableCellRenderer() {
            { setBorder(new EmptyBorder(0, 12, 0, 12)); }
        };

        DefaultTableCellRenderer rendPrio = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                String txt = v != null ? v.toString() : "";
                setForeground(Tema.corPrioridade(txt));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        DefaultTableCellRenderer rendStatus = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                String txt = v != null ? v.toString() : "";
                setForeground(Tema.corStatus(txt));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        for (int i = 0; i < mdl.getColumnCount(); i++) {
            String col = mdl.getColumnName(i);
            if      (col.equals("Prioridade")) t.getColumnModel().getColumn(i).setCellRenderer(rendPrio);
            else if (col.equals("Status"))     t.getColumnModel().getColumn(i).setCellRenderer(rendStatus);
            else                               t.getColumnModel().getColumn(i).setCellRenderer(rendPad);
        }

        t.getColumnModel().getColumn(0).setPreferredWidth(60);
        t.getColumnModel().getColumn(1).setPreferredWidth(220);
        return t;
    }

    /**
     * Popula a tabela com a lista de chamados fornecida.
     * Limpa os resultados anteriores antes de inserir os novos.
     *
     * @param lista chamados a serem exibidos
     */
    private void preencherTabela(List<Chamado> lista) {
        mdl.setRowCount(0);
        for (Chamado c : lista) {
            mdl.addRow(new Object[]{
                String.format("#%04d", c.getId()),
                c.getAssunto(),
                c.getPrioridade().toString(),
                c.getStatus().toString(),
                c.getSolicitante() != null ? c.getSolicitante().getNome() : "-",
                c.getTecnico()    != null ? c.getTecnico().getNome()    : "-",
                c.getSetor()      != null ? c.getSetor().getNome()      : "-",
                c.getDataAberturaFormatada(),
                c.getDataFechamentoFormatada()
            });
        }
    }

    /**
     * Executa a busca com base nos campos preenchidos.
     *
     * A prioridade e para o campo de ID: se preenchido, usa a BST para
     * busca exata por numero. Caso contrario, usa o campo de assunto para
     * busca textual na lista. Se ambos estiverem vazios, nenhuma busca é feita.
     */
    private void executarBusca() {
        String idTxt   = txtId.getText().trim();
        String assunto = txtAssunto.getText().trim();

        if (!idTxt.isEmpty()) {
            // Busca por ID na árvore binária: O(log n)
            try {
                int id = Integer.parseInt(idTxt);
                Chamado c = service.buscarChamadoPorId(id);
                if (c == null) {
                    Tema.alerta(janela, "Nenhum chamado encontrado com ID " + id + ".");
                } else {
                    preencherTabela(java.util.Arrays.asList(c));
                }
            } catch (NumberFormatException ex) {
                Tema.alerta(janela, "ID invalido.");
            }
        } else if (!assunto.isEmpty()) {
            // Busca por texto na lista: O(n)
            List<Chamado> result = service.buscarChamadosPorTitulo(assunto);
            if (result.isEmpty()) {
                Tema.alerta(janela, "Nenhum resultado encontrado.");
            } else {
                preencherTabela(result);
            }
        }
    }

    /**
     * Exibe todos os chamados ordenados por prioridade decrescente.
     * Útil para triagem rápida quando o técnico quer ver o que é mais urgente.
     */
    private void listarPorPrioridade() {
        preencherTabela(service.listarChamadosOrdenadosPorPrioridade());
    }

    /**
     * Limpa a tabela de resultados ao navegar para este painel.
     * O usuário precisa realizar uma nova busca; exibir resultados antigos
     * poderia causar confusão se os dados foram alterados em outro painel.
     */
    public void atualizar() {
        mdl.setRowCount(0);
    }
}
