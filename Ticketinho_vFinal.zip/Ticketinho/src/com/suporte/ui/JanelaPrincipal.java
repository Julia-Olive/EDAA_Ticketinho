package com.suporte.ui;

import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Janela principal do sistema Ticketinho.
 *
 * Contêm a sidebar de navegação a esquerda e o painel de conteúdo central.
 * Cada item do menu da sidebar corresponde a um painel de funcionalidade
 * que é instanciado uma única vez e reutilizado a cada navegação.
 *
 * Quando o usuário troca de tema (escuro/claro), toda a UI e reconstruída
 * via {@code construirUI()}. Os paineis são reinstanciados e o painel
 * que estava ativo e reexibido.
 *
 * O serviço é criado aqui e passado para todos os paineis por injeção
 * no construtor, evitando singletons globais.
 */
public class JanelaPrincipal extends JFrame {

    // Única instância do serviço, compartilhada entre todos os paineis
    private final SupportService service = new SupportService();

    // Paineis de conteúdo; cada um e instanciado apenas uma vez
    private JPanel painelConteudo;
    private PainelDashboard painelDashboard;
    private PainelChamados  painelChamados;
    private PainelHistorico painelHistorico;
    private PainelCadastros painelCadastros;
    private PainelBusca     painelBusca;

    // Botões da sidebar para controle de estado selecionado
    private JButton btnDash, btnCham, btnHist, btnCad, btnBusc;

    // Painel e botão atualmente ativos, usados para restaurar o estado após troca de tema
    private JPanel  painelAtivo;
    private JButton btnAtivo;

    /**
     * Inicializa o tema, configura a janela e constrói a interface.
     * A navegacao inicial aponta para o Dashboard.
     */
    public JanelaPrincipal() {
        Tema.init();
        configurarJanela();
        construirUI();
        navegarPara(painelDashboard, btnDash);
    }

    /**
     * Define as propriedades básicas da janela: título, tamanho mínimo,
     * tamanho inicial e posição centrada na tela.
     */
    private void configurarJanela() {
        setTitle("Ticketinho");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1200, 720));
        setSize(1380, 840);
        setLocationRelativeTo(null);
    }

    /**
     * Monta toda a estrutura visual da janela: sidebar com logo, navegação,
     * alternância de tema, badge de usuário e painel central de conteúdo.
     *
     * Este método é chamado novamente sempre que o usuário troca de tema,
     * descartando e recriando todos os componentes visuais para aplicar
     * as novas cores.
     */
    private void construirUI() {
        getContentPane().removeAll();
        getContentPane().setBackground(Tema.getBgApp());
        setLayout(new BorderLayout());

        // Sidebar lateral esquerda
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(Tema.getBgSidebar());
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setOpaque(false);
        sidebar.setPreferredSize(new Dimension(232, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Tema.getBorda()));

        // Área do logo no topo da sidebar
        JPanel logoArea = new JPanel(new BorderLayout(0, 4));
        logoArea.setOpaque(false);
        logoArea.setMaximumSize(new Dimension(232, 90));
        logoArea.setBorder(new EmptyBorder(24, 20, 20, 20));

        JPanel logoRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        logoRow.setOpaque(false);

        // Ícone hexagonal desenhado em Java2D, sem imagens externas
        JPanel hex = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = 16, cy = 16, r = 14;
                int[] xs = new int[6], ys = new int[6];
                for (int i = 0; i < 6; i++) {
                    xs[i] = cx + (int)(r * Math.cos(Math.toRadians(60 * i - 30)));
                    ys[i] = cy + (int)(r * Math.sin(Math.toRadians(60 * i - 30)));
                }
                g2.setColor(Tema.AMBAR);
                g2.fillPolygon(xs, ys, 6);
                g2.setColor(new Color(0x10, 0x12, 0x1A));
                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                FontMetrics fm = g2.getFontMetrics();
                // Centraliza a letra "T" dentro do hexagono
                g2.drawString("T", cx - fm.stringWidth("T") / 2, cy + fm.getAscent() / 2 - 1);
                g2.dispose();
            }
        };
        hex.setOpaque(false);
        hex.setPreferredSize(new Dimension(32, 32));

        // Estilização do nome Ticketinho
        JLabel lTicket = new JLabel("Ticketinho");
        lTicket.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lTicket.setForeground(Tema.AMBAR);

        logoRow.add(hex);
        logoRow.add(lTicket);

        JLabel sub = new JLabel("  Central de Atendimento");
        sub.setFont(Tema.FONTE_SMALL);
        sub.setForeground(Tema.getTextoMuted());

        logoArea.add(logoRow, BorderLayout.CENTER);
        logoArea.add(sub, BorderLayout.SOUTH);
        sidebar.add(logoArea);
        sidebar.add(sep());

        // Grupo de navegação principal
        sidebar.add(navLabel("ATENDIMENTO"));

        painelDashboard = new PainelDashboard(service, this);
        painelChamados  = new PainelChamados(service, this);
        painelHistorico = new PainelHistorico(service, this);

        btnDash = navBtn("Dashboard", NavIcon.GRID,  painelDashboard);
        btnCham = navBtn("Chamados",  NavIcon.LIST,  painelChamados);
        btnHist = navBtn("Historico", NavIcon.CLOCK, painelHistorico);
        sidebar.add(btnDash);
        sidebar.add(btnCham);
        sidebar.add(btnHist);

        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(sep());

        // Grupo de navegação administrativo
        sidebar.add(navLabel("ADMINISTRACAO"));

        painelCadastros = new PainelCadastros(service, this);
        painelBusca     = new PainelBusca(service, this);

        btnCad  = navBtn("Cadastros", NavIcon.USER,   painelCadastros);
        btnBusc = navBtn("Busca",     NavIcon.SEARCH, painelBusca);
        sidebar.add(btnCad);
        sidebar.add(btnBusc);

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(sep());
        sidebar.add(buildThemeRow());
        sidebar.add(buildUserBadge());

        // Painel central que recebe o painel ativo da navegação
        painelConteudo = new JPanel(new BorderLayout());
        painelConteudo.setBackground(Tema.getBgApp());

        add(sidebar, BorderLayout.WEST);
        add(painelConteudo, BorderLayout.CENTER);
    }

    /**
     * Enumeração dos ícones de navegação disponíveis.
     * Cada valor representa uma forma diferente desenhada em Java2D.
     */
    enum NavIcon { GRID, LIST, CLOCK, USER, SEARCH }

    /**
     * Cria um painel que desenha um ícone de navegação em Java2D.
     * O array {@code selected} usa um elemento para simular uma referência
     * mutável, necessário porque o lambda de paintComponent não pode capturar
     * variáveis locais não-finais do método que o envolve.
     *
     * @param icon     tipo do ícone a ser desenhado
     * @param selected array de um elemento indicando se o item está selecionado
     * @return painel com o ícone desenhado
     */
    private JPanel iconPanel(NavIcon icon, boolean[] selected) {
        return new JPanel() {
            { setOpaque(false); setPreferredSize(new Dimension(20, 20)); }

            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

                // Cor ambar se selecionado; cinza secundário se não
                Color c = selected[0] ? Tema.AMBAR : Tema.getTextoSecundario();
                g2.setColor(c);
                g2.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                int w = getWidth(), h = getHeight();

                switch (icon) {
                    case GRID -> {
                        // Quatro quadrados representando um grid
                        int s = 4;
                        g2.fillRoundRect(0,     0,     w/2-s/2, h/2-s/2, 3, 3);
                        g2.fillRoundRect(w/2+s/2, 0,   w/2-s/2, h/2-s/2, 3, 3);
                        g2.fillRoundRect(0,     h/2+s/2, w/2-s/2, h/2-s/2, 3, 3);
                        g2.fillRoundRect(w/2+s/2, h/2+s/2, w/2-s/2, h/2-s/2, 3, 3);
                    }
                    case LIST -> {
                        // Três linhas horizontais representando uma lista
                        g2.drawLine(0, 4,  w, 4);
                        g2.drawLine(0, 10, w, 10);
                        g2.drawLine(0, 16, w, 16);
                    }
                    case CLOCK -> {
                        // Círculo com dois ponteiros representando um relógio
                        g2.drawOval(1, 1, w-2, h-2);
                        g2.drawLine(w/2, h/2, w/2,   4);
                        g2.drawLine(w/2, h/2, w-4, h/2+2);
                    }
                    case USER -> {
                        // Cabeça oval e arco de ombros representando um usuário
                        g2.drawOval(w/2-4, 1, 8, 8);
                        g2.drawArc(1, 10, w-2, 12, -10, -160);
                    }
                    case SEARCH -> {
                        // Círculo com linha diagonal representando uma lupa
                        g2.drawOval(1, 1, w-6, h-6);
                        int lx = (int)((w-5) * Math.cos(Math.toRadians(45)));
                        int ly = (int)((h-5) * Math.sin(Math.toRadians(45)));
                        g2.drawLine(w/2-5+lx/2, h/2-5+ly/2, w-1, h-1);
                    }
                }
                g2.dispose();
            }
        };
    }

    /**
     * Cria um botão de navegação da sidebar com ícone e rótulo.
     *
     * O método {@code setSelecionado} e exposto via reflexão pelo método
     * {@code setSel()} da janela, porque a classe anônima do botão não pode
     * ser referenciada diretamente pelo tipo fora do escopo do método.
     *
     * @param label  texto do item de menu
     * @param icon   ícone associado ao item
     * @param painel painel de conteúdo que será exibido ao clicar
     * @return botão de navegação estilizado
     */
    private JButton navBtn(String label, NavIcon icon, JPanel painel) {
        boolean[] sel = {false};

        JPanel iconP = iconPanel(icon, sel);

        JLabel textLbl = new JLabel(label);
        textLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textLbl.setForeground(Tema.getTextoSecundario());

        JPanel inner = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        inner.setOpaque(false);
        inner.add(iconP);
        inner.add(textLbl);

        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                if (sel[0]) {
                    // Fundo ambar translúcido e indicador de seleção na borda esquerda
                    g2.setColor(new Color(Tema.AMBAR.getRed(), Tema.AMBAR.getGreen(), Tema.AMBAR.getBlue(), 25));
                    g2.fillRoundRect(8, 2, getWidth()-16, getHeight()-4, 8, 8);
                    g2.setColor(Tema.AMBAR);
                    g2.fillRoundRect(0, getHeight()/4, 4, getHeight()/2, 4, 4);
                } else if (getModel().isRollover()) {
                    // Fundo de hover discreto para feedback visual
                    g2.setColor(Tema.getBgHover());
                    g2.fillRoundRect(8, 2, getWidth()-16, getHeight()-4, 8, 8);
                }
                g2.dispose();
                super.paintComponent(g);
            }

            /**
             * Altera o estado visual do botão para selecionado ou não selecionado.
             * Chamado pela janela principal via reflexão ao trocar de painel.
             *
             * @param s true para selecionado
             */
            public void setSelecionado(boolean s) {
                sel[0] = s;
                textLbl.setForeground(s ? Tema.AMBAR : Tema.getTextoSecundario());
                iconP.repaint();
                repaint();
            }
        };

        btn.setLayout(new BorderLayout());
        btn.add(inner, BorderLayout.CENTER);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(7, 16, 7, 16));
        btn.setMaximumSize(new Dimension(232, 44));
        btn.setPreferredSize(new Dimension(232, 44));
        btn.addActionListener(e -> navegarPara(painel, btn));
        return btn;
    }

    /**
     * Constrói a linha de alternância de tema na parte inferior da sidebar.
     *
     * O toggle switch é desenhado inteiramente em Java2D: track com cantos
     * arredondados e knob circular com ícone de lua (modo escuro) ou sol
     * (modo claro). Ao clicar, reconstrói toda a UI para aplicar as novas cores.
     *
     * @return painel com o toggle de tema
     */
    private JPanel buildThemeRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 8));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(232, 46));

        JLabel label = new JLabel(Tema.isModoEscuro() ? "Modo Escuro" : "Modo Claro");
        label.setFont(Tema.FONTE_SMALL);
        label.setForeground(Tema.getTextoSecundario());

        JButton toggle = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int tw = 38, th = 20;
                int tx = (getWidth() - tw) / 2, ty = (getHeight() - th) / 2;

                // Track do toggle
                g2.setColor(Tema.isModoEscuro()
                        ? new Color(Tema.AMBAR.getRed(), Tema.AMBAR.getGreen(), Tema.AMBAR.getBlue(), 70)
                        : new Color(0xB0, 0xBC, 0xDC));
                g2.fill(new RoundRectangle2D.Float(tx, ty, tw, th, th, th));

                // Knob do toggle; posicionado a direita no modo escuro
                int kd = 14;
                int kx = Tema.isModoEscuro() ? tx + tw - kd - 3 : tx + 3;
                int ky = ty + (th - kd) / 2;
                g2.setColor(Tema.isModoEscuro() ? Tema.AMBAR : new Color(0x5C, 0x6A, 0xD2));
                g2.fillOval(kx, ky, kd, kd);

                //Ícone dentro do knob: lua em modo escuro, sol em modo claro
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(1.2f));
                if (Tema.isModoEscuro()) {
                    g2.drawArc(kx+2, ky+2, kd-4, kd-4, 45, 200);
                } else {
                    int cx = kx + kd/2, cy = ky + kd/2;
                    g2.drawOval(cx-3, cy-3, 6, 6);
                    for (int a = 0; a < 8; a++) {
                        double rad = Math.toRadians(45 * a);
                        g2.drawLine((int)(cx + 5*Math.cos(rad)), (int)(cy + 5*Math.sin(rad)),
                                    (int)(cx + 7*Math.cos(rad)), (int)(cy + 7*Math.sin(rad)));
                    }
                }
                g2.dispose();
            }
        };
        toggle.setPreferredSize(new Dimension(44, 28));
        toggle.setContentAreaFilled(false);
        toggle.setBorderPainted(false);
        toggle.setFocusPainted(false);
        toggle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        toggle.addActionListener(e -> {
            // Guarda o painel ativo antes de reconstruir a UI
            JPanel painelAntes = painelAtivo;
            Tema.alternarModo();
            label.setText(Tema.isModoEscuro() ? "Modo Escuro" : "Modo Claro");

            construirUI();
            revalidate();
            repaint();

            // Restaura o painel que estava ativo antes da troca de tema
            if      (painelAntes instanceof PainelDashboard) navegarPara(painelDashboard, btnDash);
            else if (painelAntes instanceof PainelChamados)  navegarPara(painelChamados,  btnCham);
            else if (painelAntes instanceof PainelHistorico) navegarPara(painelHistorico, btnHist);
            else if (painelAntes instanceof PainelCadastros) navegarPara(painelCadastros, btnCad);
            else if (painelAntes instanceof PainelBusca)     navegarPara(painelBusca,     btnBusc);
            else                                             navegarPara(painelDashboard, btnDash);
        });

        row.add(toggle);
        row.add(label);
        return row;
    }

    /**
     * Constrói o badge do usuário logado na base da sidebar.
     * Por ora exibe um usuário fixo ("Admin"), já que o sistema
     * não tem autenticação implementada.
     *
     * @return painel com o avatar e nome do usuário
     */
    private JPanel buildUserBadge() {
        JPanel badge = new JPanel(new BorderLayout(10, 0)) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(Tema.getBgHover());
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        badge.setOpaque(false);
        badge.setBorder(new EmptyBorder(12, 18, 14, 18));
        badge.setMaximumSize(new Dimension(232, 60));

        // Avatar circular com a inicial do usuário
        JPanel avatar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Tema.AMBAR);
                g2.fillOval(0, 0, 32, 32);
                g2.setColor(new Color(0x10, 0x12, 0x1A));
                g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("A", (32 - fm.stringWidth("A"))/2, (32 - fm.getHeight())/2 + fm.getAscent());
                g2.dispose();
            }
        };
        avatar.setOpaque(false);
        avatar.setPreferredSize(new Dimension(32, 32));

        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setOpaque(false);

        JLabel nome   = new JLabel("Admin");
        nome.setFont(Tema.FONTE_BOLD);
        nome.setForeground(Tema.getTextoPrimario());

        JLabel status = new JLabel("  Sistema online");
        status.setFont(Tema.FONTE_SMALL);
        status.setForeground(Tema.STATUS_VERDE);

        info.add(nome);
        info.add(status);

        badge.add(avatar, BorderLayout.WEST);
        badge.add(info, BorderLayout.CENTER);
        return badge;
    }

    /**
     * Cria um separador horizontal fino com a cor de borda do tema atual.
     * Tem largura máxima definida para não ultrapassar a sidebar.
     *
     * @return separador estilizado
     */
    private JSeparator sep() {
        JSeparator s = new JSeparator();
        s.setForeground(Tema.getBorda());
        s.setBackground(Tema.getBorda());
        s.setMaximumSize(new Dimension(232, 1));
        return s;
    }

    /**
     * Cria um rótulo de grupo de navegação em caixa alta com fonte pequena.
     * Serve para organizar visualmente os itens da sidebar em grupos.
     *
     * @param t texto do grupo em caixa alta, ex: "ATENDIMENTO"
     * @return rótulo estilizado
     */
    private JLabel navLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(Tema.getTextoMuted());
        l.setBorder(new EmptyBorder(14, 22, 4, 22));
        l.setMaximumSize(new Dimension(232, 32));
        return l;
    }

    /**
     * Navega para o painel informado, atualizando o estado visual dos botões
     * e solicitando que o painel recarregue seus dados.
     *
     * Todos os botões são desativados antes de ativar o novo, garantindo que
     * apenas um item da sidebar fique marcado por vez.
     *
     * @param painel o painel de conteúdo a ser exibido
     * @param btn    o botão da sidebar que representa este painel
     */
    public void navegarPara(JPanel painel, JButton btn) {
        // Desmarca todos os botoes
        for (JButton b : new JButton[]{btnDash, btnCham, btnHist, btnCad, btnBusc}) {
            if (b != null) setSel(b, false);
        }

        if (btn != null) setSel(btn, true);
        btnAtivo    = btn;
        painelAtivo = painel;

        // Pede ao painel que atualize seus dados antes de exibí-lo
        painelConteudo.removeAll();
        if      (painel instanceof PainelDashboard  pd) pd.atualizar();
        else if (painel instanceof PainelChamados   pc) pc.atualizar();
        else if (painel instanceof PainelHistorico  ph) ph.atualizar();
        else if (painel instanceof PainelCadastros  pca) pca.atualizar();
        else if (painel instanceof PainelBusca      pb) pb.atualizar();

        painelConteudo.add(painel, BorderLayout.CENTER);
        painelConteudo.revalidate();
        painelConteudo.repaint();
    }

    /**
     * Aciona o método {@code setSelecionado} do botão via reflexao.
     *
     * Como o botão é uma classe anônima, não podemos fazer cast diretamente.
     * A reflexão e a alternativa sem precisar extrair a classe para um arquivo
     * separado apenas para este metodo.
     *
     * @param b botao a ter o estado alterado
     * @param s true para selecionado
     */
    private void setSel(JButton b, boolean s) {
        try {
            b.getClass().getMethod("setSelecionado", boolean.class).invoke(b, s);
        } catch (Exception ignored) {}
    }

    /**
     * Solicita atualização dos paineis que dependem do estado do serviço.
     * Chamado pelos paineis de ação (Chamados) após operações que mudam dados,
     * para que o Dashboard e o Histórico reflitam as mudanças imediatamente.
     */
    public void atualizarTudo() {
        if (painelDashboard != null) painelDashboard.atualizar();
        if (painelChamados  != null) painelChamados.atualizar();
        if (painelHistorico != null) painelHistorico.atualizar();
    }
}
