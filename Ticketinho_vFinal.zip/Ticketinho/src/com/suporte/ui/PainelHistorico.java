package com.suporte.ui;

import com.suporte.model.*;
import com.suporte.service.SupportService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * Painel de histórico de chamados encerrados do Ticketinho.
 *
 * Exibe os chamados que já foram resolvidos ou cancelados, consultando
 * a pilha de histórico do serviço. A ordem de exibição é do mais recente
 * para o mais antigo, porque a pilha é percorrida do topo para a base.
 *
 * O painel é somente leitura: o usuário pode ver os detalhes de cada
 * chamado, mas não pode alterar nenhum dado.
 */
public class PainelHistorico extends JPanel {

    private final SupportService service;
    private final JanelaPrincipal janela;
    private DefaultTableModel mdl;
    private JTable tabela;

    /**
     * Cria o painel e monta a estrutura visual inicial.
     *
     * @param service serviço de suporte compartilhado
     * @param janela  referÊncia para a janela principal
     */
    public PainelHistorico(SupportService service, JanelaPrincipal janela) {
        this.service = service;
        this.janela  = janela;
        setBackground(Tema.getBgApp());
        setLayout(new BorderLayout(0, 0));
        construir();
    }

    /**
     * Monta o header com título e botão de detalhes, e a tabela de histórico.
     */
    private void construir() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(Tema.getBgApp());
        header.setBorder(new EmptyBorder(28, 28, 16, 28));

        JLabel titulo = new JLabel("Historico");
        titulo.setFont(Tema.FONTE_TITULO);
        titulo.setForeground(Tema.getTextoPrimario());
        header.add(titulo, BorderLayout.WEST);

        JButton btnDetalhe = Tema.botaoSecundario("Ver Detalhes");
        btnDetalhe.addActionListener(e -> verDetalhesSelecionado());
        header.add(btnDetalhe, BorderLayout.EAST);

        // Tabela com todas as colunas relevantes do histórico
        mdl = new DefaultTableModel(
                new String[]{"#", "Assunto", "Status Final", "Prioridade", "Tecnico",
                             "Abertura", "Atendimento", "Fechamento"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = criarTabela();

        JPanel corpo = new JPanel(new BorderLayout());
        corpo.setBackground(Tema.getBgCard());
        corpo.setBorder(new MatteBorder(0, 28, 28, 28, Tema.getBgApp()));

        JPanel inner = new JPanel(new BorderLayout());
        inner.setBackground(Tema.getBgCard());
        inner.setBorder(new LineBorder(Tema.getBorda(), 1, true));
        inner.add(Tema.scrollPane(tabela));
        corpo.add(inner);

        add(header, BorderLayout.NORTH);
        add(corpo, BorderLayout.CENTER);
    }

    /**
     * Cria a tabela do histórico com renderizadores coloridos para as colunas
     * Prioridade e Status Final.
     *
     * @return tabela estilizada pronta para uso
     */
    private JTable criarTabela() {
        JTable t = new JTable(mdl) {
            @Override public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                boolean sel = isRowSelected(row);
                c.setBackground(sel ? Tema.getSelecaoSolida()
                               : row % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                c.setForeground(Tema.getTextoPrimario());
                return c;
            }
        };
        t.setFont(Tema.FONTE_BODY);
        t.setRowHeight(38);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JTableHeader header = t.getTableHeader();
        header.setBackground(Tema.getBgSidebar());
        header.setForeground(Tema.getTextoMuted());
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setBorder(new MatteBorder(0, 0, 1, 0, Tema.getBorda()));
        header.setReorderingAllowed(false);

        DefaultTableCellRenderer rendPad = new DefaultTableCellRenderer() {
            { setBorder(new EmptyBorder(0, 12, 0, 12)); }
        };

        // Renderizador para a coluna Prioridade com cor semântica
        DefaultTableCellRenderer rendPrio = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                String txt = v != null ? v.toString() : "";
                setForeground(Tema.corPrioridade(txt));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        // Renderizador para a coluna Status Final com cor semântica
        DefaultTableCellRenderer rendStatus = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable tbl, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, v, sel, foc, r, c);
                String txt = v != null ? v.toString() : "";
                setForeground(Tema.corStatus(txt));
                setFont(Tema.FONTE_BOLD);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? Tema.getSelecaoSolida()
                             : r % 2 == 0 ? Tema.getBgCard() : Tema.getBgRowAlt());
                return this;
            }
        };

        for (int i = 0; i < mdl.getColumnCount(); i++) {
            String col = mdl.getColumnName(i);
            if      (col.equals("Prioridade"))   t.getColumnModel().getColumn(i).setCellRenderer(rendPrio);
            else if (col.equals("Status Final")) t.getColumnModel().getColumn(i).setCellRenderer(rendStatus);
            else                                 t.getColumnModel().getColumn(i).setCellRenderer(rendPad);
        }

        t.getColumnModel().getColumn(0).setPreferredWidth(60);
        t.getColumnModel().getColumn(1).setPreferredWidth(220);
        return t;
    }

    /**
     * Exibe os detalhes completos do chamado selecionado na tabela do histórico.
     *
     * Inclui o campo "Resolução" quando preenchido, o que é sempre o caso
     * para chamados no histórico (resolvidos ou cancelados com justificativa).
     */
    private void verDetalhesSelecionado() {
        int row = tabela.getSelectedRow();
        if (row < 0) {
            Tema.alerta(janela, "Selecione um chamado.");
            return;
        }

        // Recupera o chamado pela BST usando o id exibido na tabela
        String id = mdl.getValueAt(row, 0).toString().replace("#", "").trim();
        Chamado c = service.buscarChamadoPorId(Integer.parseInt(id));
        if (c == null) return;

        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Tema.getBgDialog());
        painel.setBorder(new EmptyBorder(12, 16, 12, 16));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(4, 4, 4, 12);

        String[][] campos = {
            {"Assunto:",     c.getAssunto()},
            {"Status:",      c.getStatus().toString()},
            {"Prioridade:",  c.getPrioridade().toString()},
            {"Tecnico:",     c.getTecnico() != null ? c.getTecnico().getNome() : "-"},
            {"Abertura:",    c.getDataAberturaFormatada()},
            {"Atendimento:", c.getDataAtendimentoFormatada()},
            {"Fechamento:",  c.getDataFechamentoFormatada()},
        };

        for (int i = 0; i < campos.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            JLabel lbl = new JLabel(campos[i][0]);
            lbl.setFont(Tema.FONTE_BOLD);
            lbl.setForeground(Tema.getTextoSecundario());
            painel.add(lbl, gbc);

            gbc.gridx = 1;
            JLabel val = new JLabel(campos[i][1]);
            val.setFont(Tema.FONTE_BODY);
            val.setForeground(Tema.getTextoPrimario());
            painel.add(val, gbc);
        }

        // Exibe a resolucao/justificativa apenas se existir
        if (c.getResolucao() != null && !c.getResolucao().isEmpty()) {
            gbc.gridx = 0; gbc.gridy = campos.length;
            JLabel lblR = new JLabel("Resolucao:");
            lblR.setFont(Tema.FONTE_BOLD);
            lblR.setForeground(Tema.getTextoSecundario());
            painel.add(lblR, gbc);

            gbc.gridx = 1;
            JTextArea ta = Tema.areaTexto(3);
            ta.setText(c.getResolucao());
            ta.setEditable(false);
            ta.setPreferredSize(new Dimension(300, 70));
            painel.add(Tema.scrollPane(ta), gbc);
        }

        JDialog dlg = new JDialog(janela, String.format("Historico #%04d", c.getId()), true);
        dlg.setContentPane(Tema.scrollPane(painel));
        dlg.setSize(520, 400);
        dlg.setLocationRelativeTo(janela);
        Tema.estilizarDialog(dlg);
        dlg.setVisible(true);
    }

    /**
     * Recarrega a tabela com os dados atuais da pilha de histórico.
     * A pilha é percorrida do topo para a base, então a ordem de exibição
     * jé é automaticamente do mais recente para o mais antigo.
     */
    public void atualizar() {
        mdl.setRowCount(0);
        List<Chamado> lista = service.getPilhaHistorico().toList();
        for (Chamado c : lista) {
            mdl.addRow(new Object[]{
                String.format("#%04d", c.getId()),
                c.getAssunto(),
                c.getStatus().toString(),
                c.getPrioridade().toString(),
                c.getTecnico() != null ? c.getTecnico().getNome() : "-",
                c.getDataAberturaFormatada(),
                c.getDataAtendimentoFormatada(),
                c.getDataFechamentoFormatada()
            });
        }
    }
}
