#!/bin/bash
# Script de compilacao do Ticketinho
# Requer JDK 21+

echo "=== Ticketinho - Build Script ==="

mkdir -p out

echo "[1/2] Compilando..."
find src -name "*.java" > sources.txt
javac -encoding UTF-8 --release 21 -d out @sources.txt

if [ $? -eq 0 ]; then
    echo "[2/2] Gerando JAR..."
    cat > MANIFEST.MF << 'MANIFEST'
Manifest-Version: 1.0
Main-Class: com.suporte.Main

MANIFEST
    jar cfm Ticketinho.jar MANIFEST.MF -C out .
    echo "Build concluido: Ticketinho.jar"
else
    echo "Erro na compilacao."
    exit 1
fi
