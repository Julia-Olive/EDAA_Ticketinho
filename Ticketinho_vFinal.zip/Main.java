package com.suporte;

import com.suporte.ui.JanelaPrincipal;

import javax.swing.*;

/**
 * Ponto de entrada do sistema Ticketinho.
 *
 * O uso do SwingUtilities.invokeLater garante que a criação da janela
 * aconteca dentro da Event Dispatch Thread (EDT). 
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new JanelaPrincipal().setVisible(true);
        });
    }
}
